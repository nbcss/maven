package io.github.nbcss.createfactorycontroller.content.gui.screen.recipe;

import com.simibubi.create.foundation.gui.widget.ScrollInput;
import com.simibubi.create.foundation.utility.CreateLang;
import io.github.nbcss.createfactorycontroller.content.GaugeWorkMode;
import io.github.nbcss.createfactorycontroller.content.ThresholdUnit;
import io.github.nbcss.createfactorycontroller.content.compat.fluids.FluidCompat;
import io.github.nbcss.createfactorycontroller.content.component.gauge.RecipeSlot;
import io.github.nbcss.createfactorycontroller.content.component.gauge.VirtualGaugeBehaviour;
import io.github.nbcss.createfactorycontroller.content.component.VirtualComponentPosition;
import io.github.nbcss.createfactorycontroller.content.render.ResourceIconRenderer;
import io.github.nbcss.createfactorycontroller.content.helper.TooltipBuilder;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.util.Mth;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.item.ItemStack;

import java.util.List;

/**
 * REGULAR work mode: each ingredient connection is a single total; the 3×3 grid is derived on demand
 * (full stacks first, then a partial), a slot click disconnects the whole connection, and a slot scroll
 * adjusts that connection's total. Output is a freely-scrollable produced count.
 */
class RegularEditor extends GaugeWorkModeEditor {

    RegularEditor(ConfigureRecipeScreen screen) { super(screen); }

    @Override
    void renderInputArea(GuiGraphics gfx, int mouseX, int mouseY) {
        s.patternHovered = false;
        // Scaled layout while the multiplier bar is hovered (previewScale = 1 otherwise → unchanged).
        List<ConfigureRecipeScreen.InputSlot> slots = s.layoutInputSlots(s.previewScale(mouseX, mouseY));
        for (int i = 0; i < slots.size(); i++) {
            ConfigureRecipeScreen.InputSlot slot = slots.get(i);
            int ix = cellX(i), iy = cellY(i);
            boolean fluidIng = s.isFluidConn(slot.connectionIndex());
            ItemStack stack = s.ingredientOf(s.inputConnections.get(slot.connectionIndex()));
            ResourceIconRenderer.render(gfx, stack, ix, iy);
            if (!stack.isEmpty()) {
                s.drawItemCount(gfx, stack, ix, iy, slot.amount(), fluidIng);
            }
        }
    }

    @Override
    List<FormattedCharSequence> inputTooltip(int mouseX, int mouseY) {
        int hovered = slotAt(mouseX, mouseY);
        List<ConfigureRecipeScreen.InputSlot> slots = s.layoutInputSlots(s.previewScale(mouseX, mouseY));
        if (hovered >= 0 && hovered < slots.size()) {
            ConfigureRecipeScreen.InputSlot slot = slots.get(hovered);
            boolean fluidIng = s.isFluidConn(slot.connectionIndex());
            ItemStack stack = s.ingredientOf(s.inputConnections.get(slot.connectionIndex()));
            VirtualComponentPosition source = s.inputConnections.get(slot.connectionIndex());
            int total = Math.max(1, s.inputTotals.get(slot.connectionIndex()));
            String totalLabel = fluidIng ? ThresholdUnit.formatFluidAmount(total) : String.valueOf(total);
            boolean srcIgnore = s.getMenu().componentAt(source)
                    instanceof VirtualGaugeBehaviour src && src.ignoreData;
            MutableComponent inHeader = CreateLang.translate("gui.factory_panel.sending_item",
                            FluidCompat.filterName(stack).getString() + " x" + totalLabel)
                    .color(ScrollInput.HEADER_RGB).component();
            if (!fluidIng && total > ConfigureRecipeScreen.stackSizeOf(stack))
                inHeader.append(ConfigureRecipeScreen.stackBreakdown(
                        total, ConfigureRecipeScreen.stackSizeOf(stack)));
            if (stack.isEmpty())
                return TooltipBuilder.of(Minecraft.getInstance().font)
                        .line(CreateLang.translate("gui.factory_panel.empty_panel")
                                .color(ScrollInput.HEADER_RGB).component())
                        .line(Component.translatable("createfactorycontroller.gui.action_disconnect")
                                .withStyle(ChatFormatting.DARK_GRAY, ChatFormatting.ITALIC))
                        .build();
            TooltipBuilder tooltip = TooltipBuilder.of(Minecraft.getInstance().font).line(inHeader);
            if (srcIgnore)
                tooltip.line(CreateLang.translate("gui.filter.ignore_data").style(ChatFormatting.GOLD).component());
            if (s.multiplierExcluded(source))
                tooltip.line(Component.translatable("createfactorycontroller.gui.request_multiplier.excluded")
                        .withColor(0xFFDD70));
            return tooltip.line(CreateLang.translate("gui.factory_panel.scroll_to_change_amount")
                            .style(ChatFormatting.DARK_GRAY).style(ChatFormatting.ITALIC).component())
                    .line(Component.translatable("createfactorycontroller.gui.action_disconnect")
                            .withStyle(ChatFormatting.DARK_GRAY, ChatFormatting.ITALIC))
                    .build();
        }
        if (s.inputConnections.isEmpty())
            return TooltipBuilder.of(Minecraft.getInstance().font)
                    .line(CreateLang.translate("gui.factory_panel.unconfigured_input").color(ScrollInput.HEADER_RGB).component())
                    .line(CreateLang.translate("gui.factory_panel.unconfigured_input_tip").style(ChatFormatting.GRAY).component())
                    .line(CreateLang.translate("gui.factory_panel.unconfigured_input_tip_1").style(ChatFormatting.GRAY).component())
                    .build();
        return List.of();
    }

    @Override
    VirtualComponentPosition ingredientSourceAt(double mouseX, double mouseY) {
        List<ConfigureRecipeScreen.InputSlot> slots = s.layoutInputSlots();
        int slot = slotAt(mouseX, mouseY);
        return slot >= 0 && slot < slots.size()
                ? s.inputConnections.get(slots.get(slot).connectionIndex()) : null;
    }

    @Override
    boolean inputAreaClicked(double mouseX, double mouseY, int button) {
        List<ConfigureRecipeScreen.InputSlot> slots = s.layoutInputSlots();
        int slot = slotAt(mouseX, mouseY);
        if (slot < 0 || slot >= slots.size()) return false;
        if (button == 0 && Screen.hasShiftDown()) s.disconnectInput(slots.get(slot).connectionIndex());
        return true;
    }

    @Override
    boolean inputAreaScrolled(double mouseX, double mouseY, int dir, int step) {
        List<ConfigureRecipeScreen.InputSlot> slots = s.layoutInputSlots();
        int slot = slotAt(mouseX, mouseY);
        if (slot < 0 || slot >= slots.size()) return false;
        s.adjustInputTotal(slots.get(slot).connectionIndex(), dir, Screen.hasShiftDown(), Screen.hasControlDown());
        ConfigureRecipeScreen.playScrollSound();
        return true;
    }

    @Override
    Configuration configuration() {
        return configuration(s.inputTotals, 1, 0, List.of(), List.of());
    }

    @Override
    boolean[] occupiedCells() {
        boolean[] cells = new boolean[ConfigureRecipeScreen.MAX_INPUT_SLOTS];
        // Only called while the bar is hovered, so preview at the full multiplier (scaled spill included).
        List<ConfigureRecipeScreen.InputSlot> slots = s.layoutInputSlots(s.maxRequestMultiplier);
        for (int i = 0; i < slots.size() && i < cells.length; i++)
            cells[i] = !s.multiplierExcluded(s.inputConnections.get(slots.get(i).connectionIndex()));
        return cells;
    }

    @Override
    void onChange(GaugeWorkMode previous) {
        if (previous == GaugeWorkMode.CRAFTING) {
            bakeCraftingOutput();
            int batch = s.effectiveBatch();
            for (int c = 0; c < s.inputConnections.size(); c++) {
                ItemStack ing = s.ingredientOf(s.inputConnections.get(c));
                int cells = s.craftingIngredients.stream()
                    .filter(b -> !b.stack.isEmpty() && ItemStack.isSameItemSameComponents(b.stack, ing))
                    .mapToInt(b -> Math.max(1, b.stack.getCount())).sum();
                s.inputTotals.set(c, Math.max(1, cells) * batch);
            }
            clampTotalsToGrid();
        } else if (previous == GaugeWorkMode.CUSTOM) {
            for (int c = 0; c < s.inputConnections.size(); c++) {
                VirtualComponentPosition pos = s.inputConnections.get(c);
                int total = s.customSlots.stream()
                    .filter(sl -> !sl.isEmpty() && pos.equals(sl.source()))
                    .mapToInt(RecipeSlot::count).sum();
                s.inputTotals.set(c, Math.max(1, total));
            }
            clampTotalsToGrid();
        }
    }

    /** Reduces each connection total to what still fits the 9-slot grid (best-effort, order-dependent). */
    private void clampTotalsToGrid() {
        for (int c = 0; c < s.inputConnections.size(); c++) {
            if (s.isFluidConn(c)) {
                s.inputTotals.set(c, Mth.clamp(s.inputTotals.get(c), 1, ConfigureRecipeScreen.FLUID_INGREDIENT_CAP_MB));
            } else {
                int ss = ConfigureRecipeScreen.stackSizeOf(s.ingredientOf(s.inputConnections.get(c)));
                int maxTotal = Math.max(1, ConfigureRecipeScreen.MAX_INPUT_SLOTS - s.slotsUsedExcept(c)) * ss;
                s.inputTotals.set(c, Mth.clamp(s.inputTotals.get(c), 1, maxTotal));
            }
        }
    }
}
