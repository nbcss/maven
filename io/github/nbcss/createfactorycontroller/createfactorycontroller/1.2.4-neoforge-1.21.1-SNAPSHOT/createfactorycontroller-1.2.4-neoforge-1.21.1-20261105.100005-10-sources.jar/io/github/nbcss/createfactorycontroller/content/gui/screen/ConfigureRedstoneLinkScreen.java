package io.github.nbcss.createfactorycontroller.content.gui.screen;

import com.mojang.blaze3d.systems.RenderSystem;
import com.simibubi.create.AllBlocks;
import com.simibubi.create.foundation.gui.AllIcons;
import com.simibubi.create.foundation.gui.menu.AbstractSimiContainerScreen;
import com.simibubi.create.foundation.gui.widget.ScrollInput;
import org.anti_ad.mc.ipn.api.IPNIgnore;
import com.simibubi.create.foundation.utility.CreateLang;
import io.github.nbcss.createfactorycontroller.CreateFactoryController;
import io.github.nbcss.createfactorycontroller.content.component.VirtualComponentPosition;
import io.github.nbcss.createfactorycontroller.content.block.FactoryControllerMenu;
import io.github.nbcss.createfactorycontroller.content.component.VirtualRedstoneLinkBehaviour;
import io.github.nbcss.createfactorycontroller.content.gui.screen.controller.FactoryControllerScreen;
import io.github.nbcss.createfactorycontroller.content.gui.widget.HelpButton;
import io.github.nbcss.createfactorycontroller.content.gui.widget.InteractiveAreaWidget;
import io.github.nbcss.createfactorycontroller.content.gui.widget.TooltipIconButton;
import io.github.nbcss.createfactorycontroller.content.helper.TooltipBuilder;
import io.github.nbcss.createfactorycontroller.content.packet.ConfigureRedstoneLinkPacket;
import net.createmod.catnip.gui.element.GuiGameElement;
import net.createmod.catnip.gui.element.ScreenElement;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.network.PacketDistributor;
import org.jetbrains.annotations.NotNull;

import java.util.List;

/**
 * Full-configuration overlay for a Redstone Link component.
 */
@OnlyIn(Dist.CLIENT)
@IPNIgnore
public class ConfigureRedstoneLinkScreen extends AbstractSimiContainerScreen<FactoryControllerMenu>
        implements PanelSyncListener {

    private static final ResourceLocation PANEL_TEX =
        ResourceLocation.fromNamespaceAndPath(CreateFactoryController.MODID, "textures/gui/redstone_link.png");
    private static final int PANEL_W = 200, PANEL_H = 103;

    private static final ResourceLocation PLAYER_INVENTORY_TEX =
        ResourceLocation.fromNamespaceAndPath(CreateFactoryController.MODID, "textures/gui/player_inventory.png");
    private static final int INV_TEX_W = 176, INV_TEX_H = 108, INV_TEX_HOTBAR_Y = 76;

    // Mode-button sprites.
    private static final ResourceLocation WIRELESS_TRANSMIT =
        ResourceLocation.fromNamespaceAndPath(CreateFactoryController.MODID, "icons/wireless_transmit");
    private static final ResourceLocation WIRELESS_RECEIVE =
        ResourceLocation.fromNamespaceAndPath(CreateFactoryController.MODID, "icons/wireless_receive");

    // Frequency slots (panel-relative), stacked red-over-blue; items drawn 16×16 at slot+1.
    private static final int RED_X = 87, RED_Y = 26, BLUE_X = 87, BLUE_Y = 44, SLOT = 18;

    private final FactoryControllerScreen controller;
    private final VirtualComponentPosition linkPos;

    // Staged config (committed on close).
    private ItemStack red = ItemStack.EMPTY;
    private ItemStack blue = ItemStack.EMPTY;
    private boolean receive = false;
    private boolean committed = false;

    private int panelX, panelY, invBgX, invBgY;
    private TooltipIconButton relocateButton, addConnectionButton, modeButton, confirmButton;
    private HelpButton helpButton;
    private InteractiveAreaWidget redArea, blueArea;

    public ConfigureRedstoneLinkScreen(FactoryControllerScreen controller, VirtualComponentPosition linkPos) {
        super(controller.getMenu(), Minecraft.getInstance().player.getInventory(),
              Component.translatable("createfactorycontroller.gui.redstone_link_settings"));
        this.controller = controller;
        this.linkPos = linkPos;
        if (controller.getMenu().componentAt(linkPos) instanceof VirtualRedstoneLinkBehaviour link) {
            red = link.redFreq.copy();
            blue = link.blueFreq.copy();
            receive = link.receive;
        }
        Minecraft.getInstance().getSoundManager().play(
            net.minecraft.client.resources.sounds.SimpleSoundInstance.forUI(CreateFactoryController.GAUGE_UI_OPEN.get(), 1f));
    }

    @Override
    protected void init() {
        setWindowSize(controller.guiWidth(), controller.guiHeight());
        setWindowOffset(0, 0);
        super.init();

        int blockH = PANEL_H + 6 + INV_TEX_H;
        panelX = leftPos + (imageWidth - PANEL_W) / 2;
        panelY = topPos + (imageHeight - blockH) / 2;

        // Player inventory below the panel; slot grid derived from the texture (hotbar at INV_TEX_HOTBAR_Y).
        invBgX = panelX + (PANEL_W - INV_TEX_W) / 2;
        invBgY = panelY + PANEL_H + 6;
        int originX = invBgX + 8 - leftPos;
        int hotbarY = (invBgY + INV_TEX_HOTBAR_Y) - topPos;
        menu.repositionSlots(originX, hotbarY, true);   // full inventory, ghost slot off-screen (we use fake slots)

        relocateButton = new TooltipIconButton(panelX + 8, panelY + 79, AllIcons.I_MOVE_GAUGE);
        relocateButton.withCallback(() -> {
            controller.beginRelocateMode(linkPos);
            Minecraft.getInstance().setScreen(controller);   // commit happens in removed()
        });
        relocateButton.setToolTip(Component.translatable("createfactorycontroller.gui.action_relocate"));
        addWidget(relocateButton);

        // Add-connection: same icon/flow as the recipe screen's "connect input"
        addConnectionButton = new TooltipIconButton(panelX + 30, panelY + 79, AllIcons.I_ADD);
        addConnectionButton.withCallback(() -> {
            controller.beginConnectionMode(linkPos);
            Minecraft.getInstance().setScreen(controller);   // commit happens in removed()
        });
        addConnectionButton.setToolTip(CreateLang.translate("gui.factory_panel.connect_input").component());
        addWidget(addConnectionButton);

        ScreenElement modeIcon = (gfx, x, y) -> gfx.blitSprite(receive ? WIRELESS_RECEIVE : WIRELESS_TRANSMIT, x, y, 16, 16);
        modeButton = new TooltipIconButton(panelX + 138, panelY + 79, modeIcon);
        modeButton.withCallback(() -> receive = !receive);   // staged; icon lambda reads it live
        modeButton.withTooltip(this::modeButtonTooltip);
        addWidget(modeButton);

        confirmButton = new TooltipIconButton(panelX + 167, panelY + 79, AllIcons.I_CONFIRM);
        confirmButton.withCallback(() -> Minecraft.getInstance().setScreen(controller));
        confirmButton.setToolTip(CreateLang.translate("gui.factory_panel.save_and_close").component());
        addWidget(confirmButton);

        helpButton = new HelpButton(panelX + PANEL_W - HelpButton.WIDTH - 13, panelY + 3,
                HelpButton.ColorPalette.ANDESITE, "redstone-link.html");
        addWidget(helpButton);

        redArea = addRenderableWidget(new InteractiveAreaWidget(
                panelX + RED_X, panelY + RED_Y, SLOT, SLOT,
                () -> red.isEmpty()
                        ? freqEmptyTooltip(1)
                        : TooltipBuilder.of(font).lines(getTooltipFromItem(Minecraft.getInstance(), red)).build())
                .onClick(button -> {
                    ItemStack carried = menu.getCarried();
                    red = carried.isEmpty() ? ItemStack.EMPTY : carried.copyWithCount(1);
                    return true;
                }));
        blueArea = addRenderableWidget(new InteractiveAreaWidget(
                panelX + BLUE_X, panelY + BLUE_Y, SLOT, SLOT,
                () -> blue.isEmpty()
                        ? freqEmptyTooltip(2)
                        : TooltipBuilder.of(font).lines(getTooltipFromItem(Minecraft.getInstance(), blue)).build())
                .onClick(button -> {
                    ItemStack carried = menu.getCarried();
                    blue = carried.isEmpty() ? ItemStack.EMPTY : carried.copyWithCount(1);
                    return true;
                }));
    }

    private List<FormattedCharSequence> modeButtonTooltip() {
        return TooltipBuilder.of(font)
                .line(Component.translatable("createfactorycontroller.gui.redstone_link.mode")
                        .withStyle(net.minecraft.network.chat.Style.EMPTY.withColor(ScrollInput.HEADER_RGB.getRGB())))
                .selector(Component.translatable("createfactorycontroller.gui.redstone_link.mode.receive"), receive)
                .selector(Component.translatable("createfactorycontroller.gui.redstone_link.mode.send"), !receive)
                .line(Component.translatable("createfactorycontroller.gui.request_mode.change_tip")
                        .withStyle(ChatFormatting.DARK_GRAY, ChatFormatting.ITALIC))
                .build();
    }

    @Override
    public List<net.minecraft.client.renderer.Rect2i> getExtraAreas() {
        return List.of(new net.minecraft.client.renderer.Rect2i(panelX + 195, panelY + 76, 50, 18));
    }

    @Override
    public void resize(@NotNull Minecraft minecraft, int width, int height) {
        controller.resize(minecraft, width, height);
        super.resize(minecraft, width, height);
    }

    @Override
    protected void containerTick() {
        super.containerTick();
        controller.tickComponentWidgets();
    }

    @Override
    public FactoryControllerScreen boardScreen() {
        return controller;
    }

    @Override
    public void onPanelSync() {
        controller.onPanelSync();
    }

    // ── Render ───────────────────────────────────────────────────────────────

    @Override
    public void render(GuiGraphics gfx, int mouseX, int mouseY, float partialTick) {
        super.render(gfx, mouseX, mouseY, partialTick);
        renderTooltip(gfx, mouseX, mouseY);   // hovered inventory item
        helpButton.renderTooltip(gfx, font, mouseX, mouseY);
    }

    @Override
    protected void renderBg(@NotNull GuiGraphics gfx, float partialTick, int mouseX, int mouseY) {
        controller.renderBoard(gfx, -1, -1, partialTick, true);

        RenderSystem.enableBlend();
        gfx.blit(PANEL_TEX, panelX, panelY, 0, 0, PANEL_W, PANEL_H, PANEL_W, PANEL_H);
        gfx.blit(PLAYER_INVENTORY_TEX, invBgX, invBgY, 0, 0, INV_TEX_W, INV_TEX_H);

        // Redstone Link Model
        GuiGameElement.of(AllBlocks.REDSTONE_LINK.asStack()).scale(3.0).at(0, 0, 100)
                .render(gfx, panelX + 203, panelY + 60);

        // Frequency item icons + hover highlight.
        gfx.renderItem(red, panelX + RED_X + 1, panelY + RED_Y + 1);
        gfx.renderItem(blue, panelX + BLUE_X + 1, panelY + BLUE_Y + 1);
        if (redArea.isMouseOver(mouseX, mouseY)) highlight(gfx, panelX + RED_X + 1, panelY + RED_Y + 1);
        if (blueArea.isMouseOver(mouseX, mouseY)) highlight(gfx, panelX + BLUE_X + 1, panelY + BLUE_Y + 1);

        gfx.flush();
        RenderSystem.clear(256, Minecraft.ON_OSX);

        relocateButton.render(gfx, mouseX, mouseY, partialTick);
        addConnectionButton.render(gfx, mouseX, mouseY, partialTick);
        modeButton.render(gfx, mouseX, mouseY, partialTick);
        confirmButton.render(gfx, mouseX, mouseY, partialTick);
        helpButton.render(gfx, mouseX, mouseY, partialTick);
    }

    private static void highlight(GuiGraphics gfx, int x, int y) {
        gfx.fill(x, y, x + 16, y + 16, 0x80FFFFFF);
    }

    @Override
    protected void renderForeground(@NotNull GuiGraphics gfx, int mouseX, int mouseY, float partialTicks) {
        Component title = getTitle();
        gfx.drawString(font, title, panelX + PANEL_W / 2 - font.width(title) / 2, panelY + 4, 0x3D3C48, false);
        gfx.drawString(font, playerInventoryTitle, invBgX + 8, invBgY + 6, 0x404040, false);
        super.renderForeground(gfx, mouseX, mouseY, partialTicks);
    }

    @Override
    protected void renderLabels(@NotNull GuiGraphics gfx, int mouseX, int mouseY) {}   // no default container labels

    // ── Frequency slots ────────────────────────────────────────────────────────

    /** Empty-slot hint for the given 1-indexed frequency: colored "Freq #N" + gray "Click with item to set". */
    private List<FormattedCharSequence> freqEmptyTooltip(int index) {
        ChatFormatting color = index == 1 ? ChatFormatting.RED : ChatFormatting.BLUE;
        return TooltipBuilder.of(font)
                .line(Component.translatable("createfactorycontroller.gui.redstone_link.freq_index", index)
                        .withStyle(color))
                .line(Component.translatable("createfactorycontroller.gui.redstone_link.freq_tip")
                        .withStyle(ChatFormatting.GRAY))
                .build();
    }

    /** JEI ghost / drop targets (screen coords). */
    public net.minecraft.client.renderer.Rect2i redSlotArea()  { return new net.minecraft.client.renderer.Rect2i(panelX + RED_X + 1, panelY + RED_Y + 1, 16, 16); }
    public net.minecraft.client.renderer.Rect2i blueSlotArea() { return new net.minecraft.client.renderer.Rect2i(panelX + BLUE_X + 1, panelY + BLUE_Y + 1, 16, 16); }
    public void setRedFromJei(ItemStack stack)  { red = stack.copyWithCount(1); }
    public void setBlueFromJei(ItemStack stack) { blue = stack.copyWithCount(1); }

    @Override
    protected void slotClicked(@NotNull Slot slot, int slotId, int mouseButton, @NotNull ClickType type) {
        // Shift-click an inventory item → fill the first empty type (Red, then Blue). Item isn't moved.
        if (type == ClickType.QUICK_MOVE && slot.hasItem()) {
            ItemStack freq = slot.getItem().copyWithCount(1);
            if (red.isEmpty()) red = freq;
            else if (blue.isEmpty()) blue = freq;
            return;
        }
        super.slotClicked(slot, slotId, mouseButton, type);
    }

    // ── Commit / close ─────────────────────────────────────────────────────────

    @Override
    public void onClose() {
        Minecraft.getInstance().setScreen(controller);   // return to the controller; commit fires in removed()
    }

    @Override
    public void removed() {
        commit();
        Minecraft.getInstance().getSoundManager().play(
            net.minecraft.client.resources.sounds.SimpleSoundInstance.forUI(CreateFactoryController.GAUGE_UI_CLOSE.get(), 1f));
        super.removed();
    }

    /** Sends the staged config once (idempotent across the several close paths). */
    private void commit() {
        if (committed) return;
        committed = true;
        PacketDistributor.sendToServer(new ConfigureRedstoneLinkPacket(
            menu.controllerPos, linkPos, receive, red, blue));
    }
}
