package io.github.nbcss.createfactorycontroller.content.gui.widget;

import io.github.nbcss.createfactorycontroller.content.component.arithmetic.ArithmeticTubeBehaviour;
import io.github.nbcss.createfactorycontroller.content.component.gauge.LogicalTubeBehaviour;
import io.github.nbcss.createfactorycontroller.content.component.VirtualComponentBehaviour;
import io.github.nbcss.createfactorycontroller.content.component.gauge.VirtualGaugeBehaviour;
import io.github.nbcss.createfactorycontroller.content.component.VirtualRedstoneLinkBehaviour;
import io.github.nbcss.createfactorycontroller.content.component.redstone.ButtonBehaviour;
import io.github.nbcss.createfactorycontroller.content.component.redstone.LeverBehaviour;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.jetbrains.annotations.Nullable;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Function;

/**
 * Client-side map from a component behaviour to its canvas {@link VirtualComponentWidget}, replacing the {@code
 * instanceof} chains that used to live in the screen.
 */
@OnlyIn(Dist.CLIENT)
public final class ComponentWidgetRegistry {

    private static final Map<Class<?>, Function<VirtualComponentBehaviour, VirtualComponentWidget>> FACTORIES =
            new LinkedHashMap<>();

    static {
        register(VirtualGaugeBehaviour.class, VirtualGaugeWidget::new);
        register(VirtualRedstoneLinkBehaviour.class, VirtualRedstoneLinkWidget::new);
        register(LogicalTubeBehaviour.class, VirtualLogicalTubeWidget::new);
        register(ArithmeticTubeBehaviour.class, VirtualArithmeticTubeWidget::new);
        register(LeverBehaviour.class, VirtualLeverWidget::new);
        register(ButtonBehaviour.class, VirtualButtonWidget::new);
    }

    private ComponentWidgetRegistry() {}

    @SuppressWarnings("unchecked")
    public static <T extends VirtualComponentBehaviour> void register(Class<T> type, Function<T, VirtualComponentWidget> factory) {
        FACTORIES.put(type, (Function<VirtualComponentBehaviour, VirtualComponentWidget>) factory);
    }

    /** The widget for {@code behaviour}, matching the nearest registered superclass; {@code null} if none is registered. */
    @Nullable
    public static VirtualComponentWidget create(VirtualComponentBehaviour behaviour) {
        for (Class<?> c = behaviour.getClass(); c != null; c = c.getSuperclass()) {
            Function<VirtualComponentBehaviour, VirtualComponentWidget> factory = FACTORIES.get(c);
            if (factory != null) return factory.apply(behaviour);
        }
        return null;
    }

    /** Recreates a widget for refreshed behaviour, transferring type-specific client state where possible. */
    @Nullable
    public static VirtualComponentWidget create(VirtualComponentBehaviour behaviour,
                                                @Nullable VirtualComponentWidget previous) {
        if (behaviour instanceof VirtualGaugeBehaviour gauge && previous instanceof VirtualGaugeWidget oldGauge)
            return new VirtualGaugeWidget(gauge, oldGauge);
        return create(behaviour);
    }
}
