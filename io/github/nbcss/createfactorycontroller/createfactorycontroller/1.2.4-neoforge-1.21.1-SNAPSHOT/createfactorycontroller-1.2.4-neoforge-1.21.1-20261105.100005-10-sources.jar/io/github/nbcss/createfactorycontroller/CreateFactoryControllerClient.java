package io.github.nbcss.createfactorycontroller;

import com.mojang.blaze3d.platform.InputConstants;
import com.simibubi.create.foundation.item.ItemDescription;
import com.simibubi.create.foundation.item.TooltipModifier;
import io.github.nbcss.createfactorycontroller.content.render.ProductionPatternRenderer;
import io.github.nbcss.createfactorycontroller.content.render.TerminalHoverTip;
import io.github.nbcss.createfactorycontroller.content.gui.screen.controller.FactoryControllerScreen;
import io.github.nbcss.createfactorycontroller.content.gui.screen.ProductionOrdersTab;
import io.github.nbcss.createfactorycontroller.registry.CFCItems;
import net.createmod.catnip.lang.FontHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.gui.VanillaGuiLayers;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.extensions.common.IClientItemExtensions;
import net.neoforged.neoforge.client.extensions.common.RegisterClientExtensionsEvent;
import net.neoforged.neoforge.client.gui.ConfigurationScreen;
import net.neoforged.neoforge.client.gui.IConfigScreenFactory;
import io.github.nbcss.createfactorycontroller.content.compat.DeployerCompat;
import net.liukrast.deployer.lib.helper.ClientRegisterHelpers;
import org.jetbrains.annotations.NotNull;
import org.lwjgl.glfw.GLFW;

import java.util.List;


@Mod(value = CreateFactoryController.MODID, dist = Dist.CLIENT)
@EventBusSubscriber(modid = CreateFactoryController.MODID, value = Dist.CLIENT)
public class CreateFactoryControllerClient {

    /** Cycles the hovered component's connection arrow-bend mode. Rebindable from Options ▸ Controls */
    public static final KeyMapping CYCLE_ARROW_MODE = new KeyMapping(
            "key.createfactorycontroller.cycle_arrow_mode",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_R,
            "key.categories.createfactorycontroller");

    /** Cycles the hovered component's operation mode. Rebindable from Options ▸ Controls */
    public static final KeyMapping CYCLE_OPERATION_MODE = new KeyMapping(
            "key.createfactorycontroller.cycle_operation_mode",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_F,
            "key.categories.createfactorycontroller");

    /** Starts connection mode from the hovered component */
    public static final KeyMapping START_CONNECTION = new KeyMapping(
            "key.createfactorycontroller.start_connection",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_C,
            "key.categories.createfactorycontroller");

    /** Starts relocate mode for the hovered component */
    public static final KeyMapping RELOCATE_COMPONENT = new KeyMapping(
            "key.createfactorycontroller.relocate_component",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_Q,
            "key.categories.createfactorycontroller");

    public static final KeyMapping PAN_VIEW = new KeyMapping(
            "key.createfactorycontroller.pan_view",
            InputConstants.Type.MOUSE, GLFW.GLFW_MOUSE_BUTTON_LEFT,
            "key.categories.createfactorycontroller");

    public static final KeyMapping DRAG_SELECTION = new KeyMapping(
            "key.createfactorycontroller.drag_selection",
            InputConstants.Type.MOUSE, GLFW.GLFW_MOUSE_BUTTON_LEFT,
            "key.categories.createfactorycontroller");

    public static final KeyMapping TOGGLE_ALWAYS_SHOW_LABEL = new KeyMapping(
            "key.createfactorycontroller.toggle_always_show_label",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_LEFT_ALT,
            "key.categories.createfactorycontroller");

    public static final KeyMapping SELECTION_MODE = new KeyMapping(
            "key.createfactorycontroller.selection_mode",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_LEFT_CONTROL,
            "key.categories.createfactorycontroller");

    public CreateFactoryControllerClient(ModContainer container) {
        // Allows NeoForge to create a config screen for this mod's configs.
        container.registerExtensionPoint(IConfigScreenFactory.class, ConfigurationScreen::new);
        container.registerConfig(ModConfig.Type.CLIENT, ClientConfig.SPEC);
    }

    @SubscribeEvent
    static void onClientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            // Deployer is optional: only register the keeper TAB when it's present
            if (DeployerCompat.isLoaded())
                ClientRegisterHelpers.registerStockKeeperTab(ProductionOrdersTab::new);
            // Create's shift-to-expand description (from the item's .tooltip.summary/conditionN/behaviourN keys).
            for (Item item : List.of(CFCItems.FACTORY_CONTROLLER.get(), CFCItems.FACTORY_CONTROLLER_TERMINAL.get()))
                TooltipModifier.REGISTRY.register(item,
                    new ItemDescription.Modifier(item, FontHelper.Palette.STANDARD_CREATE));
        });
    }

    @SubscribeEvent
    static void onClientLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        // Drop the session-only controller camera cache when leaving a world/server.
        FactoryControllerScreen.clearViewCache();
    }

    @SubscribeEvent
    static void onRegisterKeyMappings(RegisterKeyMappingsEvent event) {
        event.register(CYCLE_ARROW_MODE);
        event.register(CYCLE_OPERATION_MODE);
        event.register(START_CONNECTION);
        event.register(RELOCATE_COMPONENT);
        event.register(PAN_VIEW);
        event.register(DRAG_SELECTION);
        event.register(TOGGLE_ALWAYS_SHOW_LABEL);
        event.register(SELECTION_MODE);
    }

    @SubscribeEvent
    static void onRegisterGuiLayers(RegisterGuiLayersEvent event) {
        event.registerAbove(VanillaGuiLayers.HOTBAR,
                ResourceLocation.fromNamespaceAndPath(CreateFactoryController.MODID, "terminal_hover_tip"),
                TerminalHoverTip.INSTANCE);
    }

    @SubscribeEvent
    static void onClientTick(ClientTickEvent.Post event) {
        TerminalHoverTip.INSTANCE.tick();
    }

    @SubscribeEvent
    static void onRegisterClientExtensions(RegisterClientExtensionsEvent event) {
        event.registerItem(new IClientItemExtensions() {
            private final BlockEntityWithoutLevelRenderer renderer = new ProductionPatternRenderer();
            @Override
            public @NotNull BlockEntityWithoutLevelRenderer getCustomRenderer() {
                return renderer;
            }
        }, CFCItems.PRODUCTION_PATTERN.get());
    }
}
