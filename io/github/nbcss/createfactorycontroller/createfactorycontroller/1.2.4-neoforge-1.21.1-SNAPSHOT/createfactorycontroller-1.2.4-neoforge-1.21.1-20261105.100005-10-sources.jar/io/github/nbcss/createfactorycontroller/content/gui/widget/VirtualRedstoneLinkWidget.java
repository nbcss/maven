package io.github.nbcss.createfactorycontroller.content.gui.widget;

import com.simibubi.create.AllBlocks;
import com.simibubi.create.foundation.utility.CreateLang;
import io.github.nbcss.createfactorycontroller.ClientConfig;
import io.github.nbcss.createfactorycontroller.content.component.VirtualComponentPosition;
import io.github.nbcss.createfactorycontroller.content.block.FactoryControllerMenu;
import io.github.nbcss.createfactorycontroller.content.component.VirtualRedstoneLinkBehaviour;
import io.github.nbcss.createfactorycontroller.content.component.connection.RedstoneConnection;
import io.github.nbcss.createfactorycontroller.content.gui.screen.ConfigureRedstoneLinkScreen;
import io.github.nbcss.createfactorycontroller.content.gui.screen.controller.FactoryControllerScreen;
import io.github.nbcss.createfactorycontroller.content.helper.TooltipBuilder;
import io.github.nbcss.createfactorycontroller.content.packet.ConfigureRedstoneLinkPacket;
import io.github.nbcss.createfactorycontroller.content.packet.RemoveComponentPacket;
import io.github.nbcss.createfactorycontroller.content.render.BatchedBlitter;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.item.ItemStack;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.network.PacketDistributor;
import org.joml.Matrix4f;

import java.util.List;

/**
 * A redstone link on the canvas. Renders the {@code base}/{@code front} sprites with mode/power overlays, plus the two
 * type frequency icons (Red/Blue). Clicking the <b>top</b> half with an item sets the Red frequency, the
 * <b>bottom</b> half sets Blue (either mouse button, item not consumed); an empty-hand click opens the full-config GUI.
 * While holding an item, the hovered half is highlighted to show which type a click will set.
 */
@OnlyIn(Dist.CLIENT)
public record VirtualRedstoneLinkWidget(VirtualRedstoneLinkBehaviour behaviour) implements VirtualComponentWidget {

    private static final int CELL = 16;
    private static final int LABEL_INSET = 1;
    private static final float LABEL_SCALE = 0.5f;
    private static final int LABEL_COLOR = 0xFF000000 | RedstoneConnection.TYPE.color();

    @Override
    public VirtualComponentPosition position() {
        return behaviour.position();
    }

    private ResourceLocation sprite(String name) {
        return behaviour.getTexture().withSuffix("/" + name);
    }

    @Override
    public void renderBack(RenderingParameters params) {
        GuiGraphics gfx = params.graphics();
        int x0 = position().x() * CELL, y0 = position().y() * CELL;
        BatchedBlitter.forSprite(sprite("back")).blit(gfx.bufferSource(), gfx.pose(), x0, y0, CELL, CELL);
        if (behaviour.isPowered())
            BatchedBlitter.forSprite(sprite("back_power"))
                    .blit(gfx.bufferSource(), gfx.pose(), x0, y0, CELL, CELL);
    }

    @Override
    public void renderFront(RenderingParameters params) {
        GuiGraphics gfx = params.graphics();
        int x0 = position().x() * CELL, y0 = position().y() * CELL;
        BatchedBlitter.forSprite(sprite("front")).blit(gfx.bufferSource(), gfx.pose(), x0, y0, CELL, CELL);
        if (behaviour.isPowered())
            BatchedBlitter.forSprite(sprite("front_power"))
                    .blit(gfx.bufferSource(), gfx.pose(), x0, y0, CELL, CELL);
        String path = (behaviour.receive ? "receiver_" : "transmitter_") +
                (behaviour.isPowered() ? "on" : "off");
        BatchedBlitter.forSprite(sprite(path)).blit(gfx.bufferSource(), gfx.pose(), x0, y0, CELL, CELL);

        // The two 6x6 frequency icons: Red top, Blue bottom.
        renderFreqIcon(gfx, behaviour.redFreq, x0 + 5, y0 + 2);
        renderFreqIcon(gfx, behaviour.blueFreq, x0 + 5, y0 + 8);

        // While holding an item, cover the hovered half (top = Red, bottom = Blue) to show which type a click sets.
        ItemStack cursor = Minecraft.getInstance().player.containerMenu.getCarried();
        if (!cursor.isEmpty() && params.renderOverlay()) {
            boolean top = params.mousePosition().y < y0 + CELL / 2.0;
            int hy = top ? y0 : y0 + CELL / 2;
            gfx.fill(x0, hy, x0 + CELL, hy + CELL / 2, top ? 0x80FF5555 : 0x805599FF);
        }
    }

    private static void renderFreqIcon(GuiGraphics gfx, ItemStack stack, int x, int y) {
        if (stack.isEmpty()) return;
        gfx.pose().pushPose();
        gfx.pose().translate(x, y, 0);
        gfx.pose().scale(0.375f, 0.375f, 0.375f);
        gfx.renderItem(stack, 0, 0);
        gfx.pose().popPose();
    }

    @Override
    public void renderOverlay(RenderingParameters params) {
        if (!ClientConfig.showRedstoneLinkSignalStrengthLabel() || !params.renderOverlay()) return;

        GuiGraphics gfx = params.graphics();
        int x0 = position().x() * CELL, y0 = position().y() * CELL;
        String label = Integer.toString(behaviour.strength);
        Font font = Minecraft.getInstance().font;
        int width = font.width(label);

        gfx.pose().pushPose();
        gfx.pose().translate(x0 + CELL - LABEL_INSET, y0 + CELL - LABEL_INSET, 200);
        gfx.pose().scale(LABEL_SCALE, LABEL_SCALE, 1);
        Matrix4f matrix = gfx.pose().last().pose();
        font.drawInBatch8xOutline(Component.literal(label).getVisualOrderText(), -width, -font.lineHeight,
                LABEL_COLOR, 0x000000, matrix, gfx.bufferSource(), LightTexture.FULL_BRIGHT);
        gfx.pose().popPose();
    }

    @Override
    public List<FormattedCharSequence> getTooltip(FactoryControllerMenu menu, boolean selected) {
        TooltipBuilder tooltip = TooltipBuilder.of(Minecraft.getInstance().font)
                .line(CreateLang.itemName(AllBlocks.REDSTONE_LINK.asStack()).color(behaviour.getColor()).component());
        String modeKey = behaviour.receive
            ? "createfactorycontroller.gui.redstone_link.mode.receive"
            : "createfactorycontroller.gui.redstone_link.mode.send";
        tooltip.line(Component.translatable("createfactorycontroller.gui.mode_prefix",
                Component.translatable(modeKey).withStyle(ChatFormatting.WHITE))
            .withStyle(ChatFormatting.GRAY));
        tooltip.line(selected
            ? Component.translatable("createfactorycontroller.gui.drag_to_relocate").withStyle(ChatFormatting.GRAY)
            : Component.translatable("createfactorycontroller.gui.action_configure").withStyle(ChatFormatting.GRAY));
        return tooltip.line(Component.translatable("createfactorycontroller.gui.action_remove_component")
                .withStyle(ChatFormatting.DARK_GRAY)).build();
    }

    @Override
    public boolean onClick(FactoryControllerScreen screen, ItemStack carried, double mouseX, double mouseY, int button) {
        if (carried.isEmpty()) {                   // empty hand → open the full-config GUI
            screen.clearSelection();   // entering an overlay clears the selection
            Minecraft.getInstance().setScreen(new ConfigureRedstoneLinkScreen(screen, behaviour.position()));
            return true;
        }
        // Top half sets Red, bottom half sets Blue (either mouse button); the cursor item isn't consumed.
        boolean top = mouseY < position().y() * CELL + CELL / 2.0;
        ItemStack newRed = top ? carried.copy() : behaviour.redFreq;
        ItemStack newBlue = top ? behaviour.blueFreq : carried.copy();
        PacketDistributor.sendToServer(new ConfigureRedstoneLinkPacket(
            screen.getMenu().controllerPos, behaviour.position(), behaviour.receive, newRed, newBlue));
        return true;
    }

    @Override
    public void remove(FactoryControllerScreen screen) {
        if (screen.isItemTransferDenied()) return;
        PacketDistributor.sendToServer(
            new RemoveComponentPacket(screen.getMenu().controllerPos, behaviour.position()));
    }
}
