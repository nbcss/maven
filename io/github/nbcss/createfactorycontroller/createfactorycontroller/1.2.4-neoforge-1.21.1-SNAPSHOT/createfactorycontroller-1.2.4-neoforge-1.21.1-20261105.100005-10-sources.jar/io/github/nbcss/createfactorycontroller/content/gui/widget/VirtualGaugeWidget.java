package io.github.nbcss.createfactorycontroller.content.gui.widget;

import com.simibubi.create.foundation.utility.CreateLang;
import io.github.nbcss.createfactorycontroller.ClientConfig;
import io.github.nbcss.createfactorycontroller.content.block.FactoryControllerMenu;
import io.github.nbcss.createfactorycontroller.content.component.gauge.VirtualGaugeBehaviour;
import io.github.nbcss.createfactorycontroller.content.component.VirtualComponentPosition;
import io.github.nbcss.createfactorycontroller.content.compat.fluids.FluidCompat;
import io.github.nbcss.createfactorycontroller.content.component.connection.LogisticsConnection;
import io.github.nbcss.createfactorycontroller.content.gui.screen.recipe.ConfigureRecipeScreen;
import io.github.nbcss.createfactorycontroller.content.gui.screen.controller.FactoryControllerScreen;
import io.github.nbcss.createfactorycontroller.content.gui.screen.SetItemScreen;
import io.github.nbcss.createfactorycontroller.content.helper.TooltipBuilder;
import io.github.nbcss.createfactorycontroller.content.packet.GaugeSetItemPacket;
import io.github.nbcss.createfactorycontroller.content.packet.RemoveComponentPacket;
import io.github.nbcss.createfactorycontroller.content.render.BatchedBlitter;
import net.createmod.catnip.animation.AnimationTickHolder;
import net.createmod.catnip.animation.LerpedFloat;
import net.createmod.catnip.animation.LerpedFloat.Chaser;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FastColor;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.network.PacketDistributor;
import org.joml.Matrix4f;

import java.util.List;

/**
 * A single gauge on the canvas: renders it, builds its hover tooltip, and handles clicks on it.
 *
 */
@OnlyIn(Dist.CLIENT)
public final class VirtualGaugeWidget implements VirtualComponentWidget {

    private static final int CELL = 16;

    /**
     * Status indicator light, drawn top-right within the cell and tinted by gauge state.
     */
    private static final ResourceLocation INDICATOR =
            ResourceLocation.fromNamespaceAndPath("createfactorycontroller", "factory_controller/factory_gauge/indicator");

    private static final int BULB_GREEN = 0x9EFF7F;
    private static final int BULB_RED = 0xFF5555;
    private static final float BULB_MIN_BRIGHTNESS = 0.35f;

    private static final int LABEL_INSET = 1;
    private static final float LABEL_SCALE = 0.5f;
    private static final float LABEL_MIN_SCALE = 0.25f;

    private final VirtualGaugeBehaviour behaviour;
    private final LerpedFloat bulb;
    private long lastRequestTick;

    public VirtualGaugeWidget(VirtualGaugeBehaviour behaviour) {
        this.behaviour = behaviour;
        float steady = steadyGlow();
        this.bulb = LerpedFloat.linear().startWithValue(steady).chase(steady, 0.175, Chaser.EXP);
        this.lastRequestTick = behaviour.lastRequestTick;
    }

    VirtualGaugeWidget(VirtualGaugeBehaviour behaviour, VirtualGaugeWidget previous) {
        this.behaviour = behaviour;
        this.bulb = previous.bulb;
        this.lastRequestTick = previous.lastRequestTick;
    }

    @Override
    public VirtualGaugeBehaviour behaviour() {
        return behaviour;
    }

    @Override
    public void tick() {
        if (behaviour.lastRequestTick > lastRequestTick) {
            bulb.setValue(1);
            lastRequestTick = behaviour.lastRequestTick;
        }
        bulb.updateChaseTarget(steadyGlow());
        bulb.tickChaser();
    }

    private float steadyGlow() {
        return behaviour.satisfied || behaviour.redstonePowered ? 1 : 0;
    }

    public VirtualComponentPosition position() {
        return behaviour.position();
    }

    // ── Render ───────────────────────────────────────────────────────────────

    /**
     * Back layer: the gauge's {@code back} sprite. Rendered before connections.
     */
    @Override
    public void renderBack(RenderingParameters params) {
        GuiGraphics gfx = params.graphics();
        Minecraft.getInstance().getProfiler().push("VirtualGaugeWidget");
        int x0 = behaviour.position().x() * CELL;
        int y0 = behaviour.position().y() * CELL;
        BatchedBlitter.forSprite(behaviour.getTexture().withSuffix("/back"))
                .blit(gfx.bufferSource(), gfx.pose(), x0, y0, CELL, CELL);
        Minecraft.getInstance().getProfiler().pop();
    }

    /**
     * Front layer: the gauge's {@code front} sprite plus the bulb and selection outline.
     * Rendered after connections.
     */
    @Override
    public void renderFront(RenderingParameters params) {
        GuiGraphics gfx = params.graphics();
        Minecraft.getInstance().getProfiler().push("VirtualGaugeWidget");

        int x0 = behaviour.position().x() * CELL;
        int y0 = behaviour.position().y() * CELL;

        BatchedBlitter.forSprite(behaviour.getFrontTexture())
                .blit(gfx.bufferSource(), gfx.pose(), x0, y0, CELL, CELL);

        if (!behaviour.filter.isEmpty()) {
            gfx.pose().pushPose();
            gfx.pose().translate(x0 + 4.0, y0 + 4.0, 0);   // 4-px inset centres the half-size icon
            gfx.pose().scale(0.5f, 0.5f, 0.5f);            // uniform so item lighting stays correct
            params.addBatchRenderedItem(behaviour.filter, 0, 0);
            gfx.pose().popPose();
        }

        // Indicator bulb — shown once the gauge is active.
        if (behaviour.isActive()) {
            boolean invalid = behaviour.isMissingAddress() || behaviour.isRedstonePaused();
            int base = invalid ? BULB_RED : BULB_GREEN;
            float glow = bulb.getValue(AnimationTickHolder.getPartialTicks());
            float b = BULB_MIN_BRIGHTNESS + (1f - BULB_MIN_BRIGHTNESS) * Mth.clamp(glow, 0f, 1f);
            int color = FastColor.ARGB32.colorFromFloat(0.9f,
                    ((base >> 16) & 0xFF) / 255f * b,
                    ((base >> 8) & 0xFF) / 255f * b,
                    (base & 0xFF) / 255f * b);
            BatchedBlitter.forSprite(INDICATOR).setColorARGB(color)
                    .blit(gfx.bufferSource(), gfx.pose(), x0, y0, CELL, CELL);
        }

        Minecraft.getInstance().getProfiler().pop();
    }

    @Override
    public void renderOverlay(RenderingParameters params) {
        GuiGraphics gfx = params.graphics();
        Minecraft.getInstance().getProfiler().push("VirtualGaugeWidget");

        Component label = params.renderOverlay() ? behaviour.getCountLabel() : Component.empty();
        if (label.getString().isEmpty()) {
            Minecraft.getInstance().getProfiler().pop();
            return;
        }

        int x0 = behaviour.position().x() * CELL;
        int y0 = behaviour.position().y() * CELL;
        Font font = Minecraft.getInstance().font;
        int w = font.width(label);
        float scale = ClientConfig.dynamicLabelScaling()
                ? Mth.clamp((CELL - LABEL_INSET) / (float) (w + 1), LABEL_MIN_SCALE, LABEL_SCALE)
                : LABEL_SCALE;

        gfx.pose().pushPose();
        gfx.pose().translate(x0 + CELL - LABEL_INSET, y0 + CELL - LABEL_INSET, 200);
        gfx.pose().scale(scale, scale, 1);
        // Full 8-direction outline, like Create's in-world value-box labels (not a drop shadow).
        Matrix4f matrix = gfx.pose().last().pose();
        font.drawInBatch8xOutline(label.getVisualOrderText(), -w, -font.lineHeight,
                0xFFFFFFFF, 0x000000,
                matrix, gfx.bufferSource(), LightTexture.FULL_BRIGHT);
        gfx.pose().popPose();

        Minecraft.getInstance().getProfiler().pop();
    }

    // ── Tooltip ──────────────────────────────────────────────────────────────

    /** Thousands-grouped count, e.g. {@code 1,000,000} (always comma-grouped, locale-independent). */
    private static String formatCount(int value) {
        return String.format(java.util.Locale.US, "%,d", value);
    }

    private static MutableComponent stackBreakdown(int count, int ss) {
        int stacks = count / ss, overflow = count % ss;
        return Component.literal(" | " + stacks + "▤" + (overflow > 0 ? " +" + overflow : ""))
                .withStyle(ChatFormatting.DARK_GRAY);
    }

    private String formatAmount(int value) {
        return FluidCompat.isFluidFilter(behaviour.filter)
                ? behaviour.unit.formatInUnit(value)
                : formatCount(value);
    }

    /**
     * Hover tooltip, mirroring Create's factory-panel label/tip (and value-box header colour): the
     * filtered item (or "New factory task") in yellow, the interaction hint in white — "Click with
     * item to set" until a filter exists, then "Click to configure" — and, when inactive, the red
     * reason (no target amount / missing address), matching {@code FactoryPanelBehaviour#getLabel}.
     */
    @Override
    public List<FormattedCharSequence> getTooltip(FactoryControllerMenu menu, boolean selected) {
        TooltipBuilder tooltip = TooltipBuilder.of(Minecraft.getInstance().font);
        if (behaviour.filter.isEmpty()) {
            tooltip.line(CreateLang.translate("factory_panel.new_factory_task").color(behaviour.getColor()).component());
        }else{
            var title = CreateLang.text(FluidCompat.filterName(behaviour.filter).getString()).color(behaviour.getColor());
            if (behaviour.ignoreData) {
                String label = " (" + CreateLang.translate("gui.filter.ignore_data").string() + ")";
                title.add(Component.literal(label));
            }
            tooltip.line(title.component());
        }
        if (!behaviour.filter.isEmpty()) {
            MutableComponent stockLine = Component.translatable("createfactorycontroller.gui.in_stock",
                            Component.literal(behaviour.isInfiniteStock() ? "∞" : formatAmount(behaviour.stockLevel))
                                    .withStyle(ChatFormatting.WHITE))
                    .withStyle(ChatFormatting.GRAY);
            // Item filters get the recipe-screen stack breakdown, always shown (even below one stack); fluids are
            // already in their own unit and ∞ has no stack meaning.
            if (!FluidCompat.isFluidFilter(behaviour.filter) && !behaviour.isInfiniteStock())
                stockLine.append(stackBreakdown(behaviour.stockLevel, Math.max(1, behaviour.filter.getMaxStackSize())));
            tooltip.line(stockLine);
            tooltip.line(Component.translatable("createfactorycontroller.gui.promised",
                            Component.literal((behaviour.promisedCount > 0 ? "+" : "") + formatAmount(behaviour.promisedCount))
                                    .withStyle(behaviour.promisedCount > 0 ? ChatFormatting.WHITE : ChatFormatting.DARK_GRAY))
                    .withStyle(ChatFormatting.GRAY));
        }
        tooltip.line(selected
                ? Component.translatable("createfactorycontroller.gui.drag_to_relocate").withStyle(ChatFormatting.GRAY)
                : (behaviour.filter.isEmpty()
                        ? Component.translatable("createfactorycontroller.gui.set_item.filter_tip")
                        : Component.translatable("createfactorycontroller.gui.action_configure"))
                        .withStyle(ChatFormatting.GRAY));
        tooltip.line(Component.translatable("createfactorycontroller.gui.action_remove_component")
                .withStyle(ChatFormatting.DARK_GRAY));
        if (behaviour.waitingForNetwork) {
            tooltip.line(CreateLang.translate("factory_panel.some_links_unloaded").style(ChatFormatting.RED).component());
        }else if (!behaviour.incomingConnections(LogisticsConnection.TYPE).isEmpty() && !behaviour.isActive())
            tooltip.line(CreateLang.translate("gui.factory_panel.no_target_amount_set").style(ChatFormatting.RED).component());
        else if (behaviour.isMissingAddress())
            tooltip.line(CreateLang.translate("gui.factory_panel.address_missing").style(ChatFormatting.RED).component());
        else if (behaviour.isRedstonePaused())
            tooltip.line(Component.translatable("createfactorycontroller.gui.gauge_status.redstone_paused").withStyle(ChatFormatting.RED));
        return tooltip.build();
    }

    // ── Interaction ────────────────────────────────────────────────────────────

    /**
     * Shift-click: remove this gauge from the board (server refunds the item in survival).
     */
    public void remove(FactoryControllerScreen screen) {
        if (screen.isItemTransferDenied()) return;
        PacketDistributor.sendToServer(
                new RemoveComponentPacket(screen.getMenu().controllerPos, behaviour.position()));
    }

    /**
     * Left/right-click in normal mode: a filter-less gauge takes the carried item as its filter (or
     * opens the set-item overlay with an empty cursor); a configured gauge opens the recipe overlay
     * with an empty cursor. Always consumes the click.
     */
    @Override
    public boolean onClick(FactoryControllerScreen screen, ItemStack carried, double mouseX, double mouseY, int button) {
        FactoryControllerMenu menu = screen.getMenu();
        if (!behaviour.filterResolver().acceptsItemDrop()) {
            ItemStack resolved = behaviour.filterResolver().fromCarried(carried, button);
            if (!resolved.isEmpty()) {
                PacketDistributor.sendToServer(
                        new GaugeSetItemPacket(menu.controllerPos, behaviour.position(), resolved, false));
            } else if (carried.isEmpty()) {
                screen.clearSelection();
                Minecraft.getInstance().setScreen(behaviour.filter.isEmpty()
                    ? new SetItemScreen(screen, behaviour)
                    : new ConfigureRecipeScreen(screen, behaviour.position()));
            }
            return true;
        }
        if (behaviour.filter.isEmpty()) {
            if (carried.isEmpty()) {
                screen.clearSelection();   // entering an overlay clears the selection
                Minecraft.getInstance().setScreen(new SetItemScreen(screen, behaviour));
            } else
                PacketDistributor.sendToServer(
                        new GaugeSetItemPacket(menu.controllerPos, behaviour.position(), behaviour.filterResolver().fromCarried(carried, button), false));
        } else if (carried.isEmpty()) {
            screen.clearSelection();   // entering an overlay clears the selection
            Minecraft.getInstance().setScreen(new ConfigureRecipeScreen(screen, behaviour.position()));
        }
        return true;
    }

}
