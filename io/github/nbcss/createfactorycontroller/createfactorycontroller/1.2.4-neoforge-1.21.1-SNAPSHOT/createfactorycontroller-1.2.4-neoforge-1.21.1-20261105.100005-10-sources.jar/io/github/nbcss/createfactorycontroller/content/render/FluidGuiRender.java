package io.github.nbcss.createfactorycontroller.content.render;

import com.mojang.blaze3d.platform.Lighting;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.createmod.catnip.platform.NeoForgeCatnipServices;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.fluids.FluidStack;

/**
 * GUI rendering for fluids.
 */
@OnlyIn(Dist.CLIENT)
public final class FluidGuiRender {

    private FluidGuiRender() {}

    /**
     * A flat, front-facing fluid icon filling a {@code size}px square at {@code (x, y)} — a thin slab so the fluid's
     * animated still sprite faces the viewer, like CreateFluidLogistic's own slot icon.
     */
    public static void icon(GuiGraphics gfx, FluidStack fluid, int x, int y, int size) {
        if (fluid.isEmpty()) return;
        PoseStack ps = gfx.pose();
        ps.pushPose();
        ps.translate(x + size / 2f, y + size / 2f, 100);
        ps.scale(size, -size, size);

        Lighting.setupForFlatItems();
        MultiBufferSource.BufferSource buffer = gfx.bufferSource();
        // Thin slab (z ∈ [-1/32, 0]) so only the viewer-facing +Z face shows: a flat fluid icon.
        NeoForgeCatnipServices.FLUID_RENDERER.renderFluidBox(
            fluid, -0.5f, -0.5f, -1 / 32f, 0.5f, 0.5f, 0f, buffer, ps, LightTexture.FULL_BRIGHT, true, false);
        gfx.flush();
        Lighting.setupFor3DItems();
        ps.popPose();
    }

    /**
     * The recipe-screen preview
     */
    public static void cube(GuiGraphics gfx, FluidStack fluid, int x, int y, float px) {
        if (fluid.isEmpty()) return;
        PoseStack ps = gfx.pose();
        ps.pushPose();
        ps.translate(x + px / 2f, y + px / 2f, 250);                 // centre the block on the slot
        ps.scale(px, -px, px);                                       // GUI px → model units (flip Y for GUIs)
        ps.mulPose(Axis.XP.rotationDegrees(30));                     // vanilla block-in-inventory GUI orientation
        ps.mulPose(Axis.YP.rotationDegrees(225));                    // (matches how the gauge block beside it is lit)
        ps.translate(-0.5f, -0.5f, -0.5f);                          // origin → cube centre

        Lighting.setupFor3DItems();                                  // directional shading, like a 3D block item
        MultiBufferSource.BufferSource buffer = gfx.bufferSource();
        NeoForgeCatnipServices.FLUID_RENDERER.renderFluidBox(
            fluid, 0, 0, 0, 1, 1, 1, buffer, ps, LightTexture.FULL_BRIGHT, true, true);
        buffer.endBatch();
        ps.popPose();
    }
}
