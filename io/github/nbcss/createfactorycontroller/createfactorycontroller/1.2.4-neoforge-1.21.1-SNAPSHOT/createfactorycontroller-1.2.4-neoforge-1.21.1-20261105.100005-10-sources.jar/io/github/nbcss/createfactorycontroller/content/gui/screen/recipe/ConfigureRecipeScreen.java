package io.github.nbcss.createfactorycontroller.content.gui.screen.recipe;

import com.mojang.blaze3d.systems.RenderSystem;
import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllRecipeTypes;
import com.simibubi.create.AllSoundEvents;
import com.simibubi.create.content.kinetics.crafter.MechanicalCraftingRecipe;
import com.simibubi.create.content.logistics.AddressEditBox;
import com.simibubi.create.content.logistics.BigItemStack;
import com.simibubi.create.content.logistics.box.PackageStyles;
import com.simibubi.create.content.trains.station.NoShadowFontWrapper;
import com.simibubi.create.foundation.gui.AllIcons;
import com.simibubi.create.foundation.gui.menu.AbstractSimiContainerScreen;
import com.simibubi.create.foundation.gui.widget.ScrollInput;
import org.anti_ad.mc.ipn.api.IPNIgnore;
import io.github.nbcss.createfactorycontroller.content.render.FluidGuiRender;
import io.github.nbcss.createfactorycontroller.content.render.ResourceIconRenderer;
import io.github.nbcss.createfactorycontroller.content.render.SpriteNumbersRender;
import net.createmod.catnip.gui.element.ScreenElement;
import com.simibubi.create.foundation.utility.CreateLang;
import com.simibubi.create.infrastructure.config.AllConfigs;
import io.github.nbcss.createfactorycontroller.ClientConfig;
import io.github.nbcss.createfactorycontroller.CreateFactoryController;
import io.github.nbcss.createfactorycontroller.ServerConfig;
import io.github.nbcss.createfactorycontroller.content.block.FactoryControllerMenu;
import io.github.nbcss.createfactorycontroller.content.GaugeWorkMode;
import io.github.nbcss.createfactorycontroller.content.RequestMode;
import io.github.nbcss.createfactorycontroller.content.ThresholdUnit;
import io.github.nbcss.createfactorycontroller.content.component.gauge.RecipeSlot;
import io.github.nbcss.createfactorycontroller.content.component.connection.LogisticsConnection;
import io.github.nbcss.createfactorycontroller.content.component.VirtualComponentBehaviour;
import io.github.nbcss.createfactorycontroller.content.component.gauge.VirtualGaugeBehaviour;
import io.github.nbcss.createfactorycontroller.content.component.connection.Connection;
import io.github.nbcss.createfactorycontroller.content.component.VirtualComponentPosition;
import io.github.nbcss.createfactorycontroller.content.compat.fluids.FluidCompat;
import io.github.nbcss.createfactorycontroller.content.gui.screen.controller.FactoryControllerScreen;
import io.github.nbcss.createfactorycontroller.content.gui.screen.GaugeInfoClient;
import io.github.nbcss.createfactorycontroller.content.gui.screen.PanelSyncListener;
import io.github.nbcss.createfactorycontroller.content.gui.widget.HelpButton;
import io.github.nbcss.createfactorycontroller.content.gui.widget.InteractiveAreaWidget;
import io.github.nbcss.createfactorycontroller.content.gui.widget.TooltipIconButton;
import io.github.nbcss.createfactorycontroller.content.helper.TooltipBuilder;
import io.github.nbcss.createfactorycontroller.content.packet.ConfigureRecipePacket;
import io.github.nbcss.createfactorycontroller.content.packet.DisconnectIngredientPacket;
import io.github.nbcss.createfactorycontroller.content.packet.DisconnectLinksPacket;
import io.github.nbcss.createfactorycontroller.content.packet.RequestGaugePromiseInfoPacket;
import io.github.nbcss.createfactorycontroller.content.packet.SetGaugeRequestIntervalPacket;
import net.createmod.catnip.gui.element.GuiGameElement;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.tooltip.TooltipRenderUtil;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.CraftingRecipe;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.crafting.ShapedRecipe;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.network.PacketDistributor;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Recipe-configuration overlay for a virtual gauge.
 */
@OnlyIn(Dist.CLIENT)
@IPNIgnore
public class ConfigureRecipeScreen extends AbstractSimiContainerScreen<FactoryControllerMenu> implements PanelSyncListener {
    private static final ResourceLocation PANEL_TEX =
        ResourceLocation.fromNamespaceAndPath(CreateFactoryController.MODID, "textures/gui/configure_recipe.png");
    private static final int PANEL_W = 200, PANEL_H = 184;
    static final int MAX_INPUT_SLOTS = VirtualGaugeBehaviour.MAX_INGREDIENTS;
    private static final int MAX_CRAFT_OUTPUT = 64;
    private static final int THRESH_TOP = 128;
    private static final int FILTER_X = 25;
    private static final int COUNT_X = 51, COUNT_W = 40;
    private static final int UNIT_X = 95, UNIT_W = 50;
    private static final int REQUEST_MODE_BTN_X = 150;
    private static final int THRESH_H = 18;
    private static final int PROMISE_CLEAR_X = 10;
    private static final int PROMISE_TIMEOUT_X = 44, PROMISE_TIMEOUT_W = 32;
    private static final int PROMISE_LIMIT_X = 92, PROMISE_LIMIT_W = 42;
    private static final int LINK_RESET_X = 12, LINK_RESET_Y = 48;
    private static final int OUTPUT_X = 160, OUTPUT_Y = 48;
    private static final int MULTIPLIER_X = 64, MULTIPLIER_Y = 87, MULTIPLIER_W = 64, MULTIPLIER_H = 8;
    private static final int REQUEST_MULTIPLIER_COLOR = 0x43FFDD70;
    // Request-timer charge-up animation
    private static final ResourceLocation ARROW_ANIM_TEX =
        ResourceLocation.fromNamespaceAndPath(CreateFactoryController.MODID, "textures/gui/gauge_arrow_animation.png");
    private static final int ARROW_ANIM_FRAMES = 15, ARROW_ANIM_W = 15, ARROW_ANIM_H = 17;
    private static final int ARROW_ANIM_X = 140, ARROW_ANIM_Y = 47;
    // Request-interval custom value on the arrow
    private static final int INTERVAL_RIGHT_X = 154, INTERVAL_Y = 58;
    private static final int INTERVAL_CUSTOM_COLOR = 0xFF9ECFFC;
    private static final int INTERVAL_DISABLE_COLOR = 0xFF999999;
    private static final int MULTIPLIER_COLOR = 0xFFFFDD70;
    private static final int MULTIPLIER_DISABLE_COLOR = 0xFFE0E0E0;
    private static final int TICKS_PER_SEC = 20;

    private final FactoryControllerScreen controller;
    private final VirtualComponentPosition gaugePos;

    int panelX, panelY;

    /** Whether {@code (mx, my)} lies within this screen's panel — used by {@link CustomArrangementEditor} to
     *  treat a drag released past the panel's edge as "drop the item" (same as shift-click removal). */
    boolean inPanelBounds(double mx, double my) {
        return mx >= panelX && mx < panelX + PANEL_W && my >= panelY && my < panelY + PANEL_H;
    }

    // Editable / derived state.
    int outputCount = 1;
    /** Crafts per request in crafting mode (≥1). The output slot shows outputCount × craftBatch. */
    int craftBatch = 1;
    /** User-set request-multiplier ceiling (≥1, default 1). */
    int maxRequestMultiplier = 1;
    /** Per-gauge request interval in TICKS; 0 = unspecified → Create's config. */
    int customRequestTimer = 0;
    /** Square crafter-grid size a recipe is laid out for; defaults to its minimum (3x3). 0 until a recipe loads. */
    private int craftDimension = 0;
    private int thresholdCount = 0;
    /** Click-to-type editing of the count box: true while typing. */
    private boolean countEditing = false;
    private String countEdit = "";
    private ThresholdUnit mode = ThresholdUnit.ITEMS;
    private RequestMode requestMode = RequestMode.NORMAL;
    /** True when the gauge's filter is a fluid filter */
    boolean fluidMode = false;
    // One entry per input CONNECTION (not per grid slot): the source gauge and its TOTAL item count.
    final List<VirtualComponentPosition> inputConnections = new ArrayList<>();
    final List<Integer> inputTotals = new ArrayList<>();
    final List<BigItemStack> inputConfig = new ArrayList<>();   // for crafting-recipe search
    /** Local recipe edit: source connections sent once per request instead of scaled by the multiplier. */
    final Set<VirtualComponentPosition> multiplierExcludedInputs = new HashSet<>();

    @Nullable private CraftingRecipe availableCraftingRecipe;
    /** The active work mode (regular / crafting / custom); mirrors the gauge's, edited locally until sent. */
    GaugeWorkMode workMode = GaugeWorkMode.REGULAR;
    /** CUSTOM mode: the local 9-slot layout being edited (index = grid slot); {@link RecipeSlot#EMPTY} for a gap. */
    List<RecipeSlot> customSlots = new ArrayList<>();

    // Per-mode behaviour of the ingredient grid + output; the screen delegates to the active one.
    private final RegularEditor regularEditor = new RegularEditor(this);
    private final CraftingEditor craftingEditor = new CraftingEditor(this);
    private final CustomArrangementEditor customEditor = new CustomArrangementEditor(this);
    private GaugeWorkModeEditor editor() {
        return switch (workMode) {
            case CRAFTING -> craftingEditor;
            case CUSTOM -> customEditor;
            default -> regularEditor;
        };
    }
    List<BigItemStack> craftingIngredients = new ArrayList<>();
    /** Set in renderBg when Ctrl is held over a crafting ingredient, so renderForeground draws the N×M layout. */
    boolean patternHovered;

    private AddressEditBox addressBox;
    private ScrollInput promiseExpiration;
    private int promiseLimitState = -1;
    /** Local edit of the limit scope (click the limit box to cycle): false = this gauge's own in-flight requests,
     *  true = all requests network-wide to this gauge's address. */
    private boolean promiseLimitByAddress = false;
    /** Ticks until the next on-demand poll of the gauge's live promise counts (server round-trip). */
    private int promiseInfoPollCooldown = 0;
    private TooltipIconButton confirmButton;
    private TooltipIconButton deleteButton;
    private TooltipIconButton newInputButton;
    private TooltipIconButton relocateButton;
    @Nullable private TooltipIconButton craftingButton;
    private TooltipIconButton customButton;
    @Nullable private TooltipIconButton disconnectLinkButton;
    /** Cycles the gauge's {@link RequestMode}; its icon reflects the current mode. */
    @Nullable private TooltipIconButton requestModeButton;
    private HelpButton helpButton;
    private InteractiveAreaWidget multiplierArea;
    private InteractiveAreaWidget countArea;
    private InteractiveAreaWidget ingredientArea;

    public ConfigureRecipeScreen(FactoryControllerScreen controller, VirtualComponentPosition gaugePos) {
        super(controller.getMenu(), Minecraft.getInstance().player.getInventory(),
              CreateLang.translate("gui.factory_panel.title_as_recipe").component());
        this.controller = controller;
        this.gaugePos = gaugePos;
        updateConfigs();   // snapshot once (not per init, so edits/crafting toggle survive resize)
        Minecraft.getInstance().getSoundManager().play(
            SimpleSoundInstance.forUI(CreateFactoryController.GAUGE_UI_OPEN.get(), 1f));
    }

    @Override
    protected void init() {
        setWindowSize(controller.guiWidth(), controller.guiHeight());
        setWindowOffset(0, 0);
        super.init();

        // No inventory here — push all shared-menu slots off-screen.
        menu.repositionSlots(-10000, -10000, false);

        panelX = leftPos + (imageWidth - PANEL_W) / 2;
        panelY = topPos + (imageHeight - PANEL_H) / 2;

        VirtualGaugeBehaviour g = getBehaviour();

        // Preserve any unsaved edits across re-init (the crafting toggle re-runs init()).
        String address = addressBox != null ? addressBox.getValue() : (g == null ? "" : g.recipeAddress);
        boolean firstInit = promiseExpiration == null;
        int promiseState = !firstInit ? promiseExpiration.getState() : (g == null ? -1 : g.promiseClearingInterval);
        int limitState = promiseLimitState >= 0 ? promiseLimitState : (g == null ? 0 : g.promiseLimit);
        promiseLimitByAddress = !firstInit ? promiseLimitByAddress : (g != null && g.promiseLimitByAddress);

        // Create's address box with frogport-address autocomplete
        addressBox = new AddressEditBox(this, new NoShadowFontWrapper(font),
            panelX + 36, panelY + PANEL_H - 77, 108, 10, false);
        addressBox.setBordered(false);
        addressBox.setTextColor(0x555555);
        addressBox.setValue(address);
        addWidget(addressBox);
        addRenderableOnly(new InteractiveAreaWidget(
                addressBox.getX(), addressBox.getY(), addressBox.getWidth(), addressBox.getHeight(),
                () -> addressBox.isFocused()
                        ? List.of()
                        : TooltipBuilder.of(font).lines(addressBox.getValue().isBlank()
                                ? List.of(
                                        CreateLang.translate("gui.factory_panel.recipe_address")
                                                .color(ScrollInput.HEADER_RGB).component(),
                                        CreateLang.translate("gui.factory_panel.recipe_address_tip")
                                                .style(ChatFormatting.GRAY).component(),
                                        CreateLang.translate("gui.factory_panel.recipe_address_tip_1")
                                                .style(ChatFormatting.GRAY).component(),
                                        CreateLang.translate("gui.schedule.lmb_edit")
                                                .style(ChatFormatting.DARK_GRAY).style(ChatFormatting.ITALIC).component())
                                : List.of(
                                        CreateLang.translate("gui.factory_panel.recipe_address_given")
                                                .color(ScrollInput.HEADER_RGB).component(),
                                        CreateLang.text("'" + addressBox.getValue() + "'")
                                                .style(ChatFormatting.GRAY).component())).build()));

        promiseExpiration = new ScrollInput(panelX + PROMISE_TIMEOUT_X, panelY + PANEL_H - 24, PROMISE_TIMEOUT_W, 16)
            .withRange(-1, 31)
            .titled(CreateLang.translate("gui.factory_panel.promises_expire_title").component());
        promiseExpiration.setState(promiseState);
        addWidget(promiseExpiration);

        promiseLimitState = limitState;

        confirmButton = new TooltipIconButton(panelX + PANEL_W - 33, panelY + PANEL_H - 25, AllIcons.I_CONFIRM);
        confirmButton.withCallback(this::confirmAndReturn);
        confirmButton.setToolTip(CreateLang.translate("gui.factory_panel.save_and_close").component());
        addWidget(confirmButton);

        deleteButton = new TooltipIconButton(panelX + PANEL_W - 55, panelY + PANEL_H - 25, AllIcons.I_TRASH);
        deleteButton.withCallback(this::deleteAndReturn);
        deleteButton.setToolTip(CreateLang.translate("gui.factory_panel.reset").component());
        addWidget(deleteButton);

        newInputButton = new TooltipIconButton(panelX + 31, panelY + 47, AllIcons.I_ADD);
        newInputButton.withCallback(() -> {
            sendConfig(false, false);   // commit edits before leaving the screen
            controller.beginConnectionMode(gaugePos);
            Minecraft.getInstance().setScreen(controller);
        });
        newInputButton.setToolTip(CreateLang.translate("gui.factory_panel.connect_input").component());
        addWidget(newInputButton);

        relocateButton = new TooltipIconButton(panelX + 31, panelY + 67, AllIcons.I_MOVE_GAUGE);
        relocateButton.withCallback(() -> {
            sendConfig(false, false);   // commit edits (incl. repeated slots) before leaving the screen
            controller.beginRelocateMode(gaugePos);
            Minecraft.getInstance().setScreen(controller);
        });
        relocateButton.setToolTip(Component.translatable("createfactorycontroller.gui.action_relocate"));
        addWidget(relocateButton);

        // Mechanical-crafting toggle
        craftingButton = null;
        if (availableCraftingRecipe != null) {
            craftingButton = new TooltipIconButton(panelX + 11, panelY + 27, AllIcons.I_3x3);
            craftingButton.green = workMode == GaugeWorkMode.CRAFTING;
            craftingButton.withCallback(() -> {
                if (availableCraftingRecipe == null) return;
                GaugeWorkMode prev = workMode;
                workMode = prev == GaugeWorkMode.CRAFTING ? GaugeWorkMode.REGULAR : GaugeWorkMode.CRAFTING;
                if (workMode == GaugeWorkMode.CRAFTING) multiplierExcludedInputs.clear();
                editor().onChange(prev);
                rebuildWidgets();
            });
            craftingButton.withTooltip(this::craftingButtonTooltip);
            addWidget(craftingButton);
        }

        // Custom Arrangement toggle
        customButton = new TooltipIconButton(panelX + 31, panelY + 27, (gfx, x, y) -> gfx.blitSprite(
                ResourceLocation.fromNamespaceAndPath(CreateFactoryController.MODID, "icons/custom_arrangement"),
                x, y, 16, 16));
        customButton.green = workMode == GaugeWorkMode.CUSTOM;
        customButton.withCallback(() -> {
            GaugeWorkMode prev = workMode;
            workMode = prev == GaugeWorkMode.CUSTOM ? GaugeWorkMode.REGULAR : GaugeWorkMode.CUSTOM;
            editor().onChange(prev);   // CUSTOM seeds its 9-slot layout from the outgoing mode
            rebuildWidgets();
        });
        customButton.withTooltip(this::customButtonTooltip);
        addWidget(customButton);

        // Request-mode cycle button
        requestModeButton = new TooltipIconButton(panelX + REQUEST_MODE_BTN_X, panelY + THRESH_TOP - 1, iconFor(requestMode));
        requestModeButton.withCallback(this::cycleRequestMode);
        requestModeButton.withTooltip(this::requestModeButtonTooltip);
        addWidget(requestModeButton);

        disconnectLinkButton = null;
        if (hasLinkConnections()) {
            disconnectLinkButton = new TooltipIconButton(panelX + LINK_RESET_X - 1, panelY + LINK_RESET_Y - 1,
                    (gfx, x, y) -> gfx.blitSprite(
                            ResourceLocation.fromNamespaceAndPath(CreateFactoryController.MODID, "icons/connected"),
                            x, y, 16, 16)
            );
            disconnectLinkButton.withCallback(() -> {
                PacketDistributor.sendToServer(new DisconnectLinksPacket(menu.controllerPos, gaugePos));
                removeWidget(disconnectLinkButton);
                disconnectLinkButton = null;
            });
            disconnectLinkButton.setToolTip(Component.translatable("createfactorycontroller.gui.disconnect_links")
                    .withStyle(ChatFormatting.WHITE));
            addWidget(disconnectLinkButton);
        }

        helpButton = new HelpButton(panelX + PANEL_W - HelpButton.WIDTH - 13, panelY + 3,
                HelpButton.ColorPalette.LOGISTICS, "factory-gauge.html");
        addWidget(helpButton);

        addRenderableWidget(new InteractiveAreaWidget(panelX + OUTPUT_X, panelY + OUTPUT_Y, 16, 16,
                () -> {
                    VirtualGaugeBehaviour behaviour = getBehaviour();
                    if (behaviour == null || behaviour.filter.isEmpty()) return List.of();
                    int producedCount = editor().producedCount();
                    String produced = fluidMode
                            ? ThresholdUnit.formatFluidAmount(producedCount) : String.valueOf(producedCount);
                    MutableComponent header = CreateLang.translate("gui.factory_panel.expected_output",
                                    FluidCompat.filterName(behaviour.filter).getString() + " x" + produced)
                            .color(ScrollInput.HEADER_RGB).component();
                    if (!fluidMode && producedCount > outputStackSize())
                        header.append(stackBreakdown(producedCount, outputStackSize()));
                    TooltipBuilder tooltip = TooltipBuilder.of(font).line(header);
                    if (behaviour.ignoreData)
                        tooltip.line(CreateLang.translate("gui.filter.ignore_data")
                                .style(ChatFormatting.GOLD).component());
                    return tooltip.line(CreateLang.translate("gui.factory_panel.expected_output_tip")
                                    .style(ChatFormatting.GRAY).component())
                            .line(CreateLang.translate("gui.factory_panel.expected_output_tip_1")
                                    .style(ChatFormatting.GRAY).component())
                            .line(CreateLang.translate("gui.factory_panel.expected_output_tip_2")
                                    .style(ChatFormatting.DARK_GRAY).style(ChatFormatting.ITALIC).component())
                            .build();
                }).onScroll((scrollX, scrollY) -> {
            int dir = (int) Math.signum(scrollY);
            int step = hasControlDown() ? 100 : hasShiftDown() ? 10 : 1;
            return editor().outputScrolled(dir, step);
        }));
        multiplierArea = addRenderableWidget(new InteractiveAreaWidget(
                panelX + MULTIPLIER_X, panelY + MULTIPLIER_Y, MULTIPLIER_W, MULTIPLIER_H,
                () -> {
                    VirtualGaugeBehaviour behaviour = getBehaviour();
                    if (behaviour == null || behaviour.filter.isEmpty()) return List.of();
                    TooltipBuilder lines = TooltipBuilder.of(font)
                            .line(Component.translatable("createfactorycontroller.gui.request_multiplier",
                                    maxRequestMultiplier, structuralMultiplierCap())
                                    .withStyle(net.minecraft.network.chat.Style.EMPTY.withColor(ScrollInput.HEADER_RGB.getRGB())))
                            .wrapped(Component.translatable("createfactorycontroller.gui.request_multiplier.tip")
                                    .withStyle(ChatFormatting.GRAY));
                    if (workMode != GaugeWorkMode.CRAFTING)
                        lines.line(Component.translatable("createfactorycontroller.gui.request_multiplier.exclude_tip")
                                .withStyle(ChatFormatting.DARK_GRAY, ChatFormatting.ITALIC));
                    return lines.line(CreateLang.translate("gui.factory_panel.scroll_to_change_amount")
                                    .style(ChatFormatting.DARK_GRAY).style(ChatFormatting.ITALIC).component())
                            .build();
                }).onClick(button -> {
            if (button != 0 && button != 1) return false;
            maxRequestMultiplier = button == 1 ? 1 : structuralMultiplierCap();
            playClickSound();
            return true;
        }).onScroll((scrollX, scrollY) -> {
            int dir = (int) Math.signum(scrollY);
            if (dir != 0) {
                int step = hasShiftDown() ? 10 : 1;
                maxRequestMultiplier = Mth.clamp(
                        maxRequestMultiplier + dir * step, 1, structuralMultiplierCap());
                playScrollSound();
            }
            return true;
        }));
        addRenderableWidget(new InteractiveAreaWidget(
                panelX + ARROW_ANIM_X, panelY + ARROW_ANIM_Y, ARROW_ANIM_W, ARROW_ANIM_H,
                () -> {
                    int ticks = customRequestTimer > 0
                            ? customRequestTimer : AllConfigs.server().logistics.factoryGaugeTimer.get();
                    String seconds = ticks % TICKS_PER_SEC == 0
                            ? String.valueOf(ticks / TICKS_PER_SEC)
                            : String.format(java.util.Locale.ROOT, "%.1f", ticks / (float) TICKS_PER_SEC);
                    TooltipBuilder lines = TooltipBuilder.of(font)
                            .line(Component.translatable("createfactorycontroller.gui.request_interval", seconds)
                                    .withStyle(net.minecraft.network.chat.Style.EMPTY.withColor(ScrollInput.HEADER_RGB.getRGB())))
                            .wrapped(Component.translatable("createfactorycontroller.gui.request_interval.tips")
                                    .withStyle(ChatFormatting.GRAY))
                            .line(CreateLang.translate("gui.factory_panel.scroll_to_change_amount")
                                    .style(ChatFormatting.DARK_GRAY).style(ChatFormatting.ITALIC).component());
                    if (customRequestTimer > 0)
                        lines.line(Component.translatable("createfactorycontroller.gui.request_interval.reset")
                                .withStyle(ChatFormatting.DARK_GRAY, ChatFormatting.ITALIC));
                    return lines.build();
                }).onClick(button -> {
            if (customRequestTimer > 0) {
                setRequestInterval(0);
                playClickSound();
            }
            return true;
        }).onScroll((scrollX, scrollY) -> {
            int dir = (int) Math.signum(scrollY);
            if (dir != 0) {
                setRequestInterval(Mth.clamp(shownIntervalSeconds() + dir, 1, 60) * TICKS_PER_SEC);
                playScrollSound();
            }
            return true;
        }));
        addRenderableWidget(new InteractiveAreaWidget(
                panelX + PROMISE_CLEAR_X, panelY + PANEL_H - 24, 16, 16,
                () -> {
                    VirtualGaugeBehaviour behaviour = getBehaviour();
                    int promised = behaviour == null ? 0 : behaviour.promisedCount;
                    if (promised == 0)
                        return TooltipBuilder.of(font)
                                .line(CreateLang.translate("gui.factory_panel.no_open_promises")
                                        .color(ScrollInput.HEADER_RGB).component())
                                .line(CreateLang.translate("gui.factory_panel.recipe_promises_tip")
                                        .style(ChatFormatting.GRAY).component())
                                .line(CreateLang.translate("gui.factory_panel.recipe_promises_tip_1")
                                        .style(ChatFormatting.GRAY).component())
                                .line(CreateLang.translate("gui.factory_panel.promise_prevents_oversending")
                                        .style(ChatFormatting.GRAY).component())
                                .build();
                    String promisedLabel = FluidCompat.isFluidFilter(behaviour.filter)
                            ? formatFluidShort(promised) : String.valueOf(promised);
                    return TooltipBuilder.of(font)
                            .line(CreateLang.translate("gui.factory_panel.promised_items")
                                    .color(ScrollInput.HEADER_RGB).component())
                            .line(CreateLang.text(FluidCompat.filterName(behaviour.filter).getString() + " x" + promisedLabel)
                                    .component())
                            .line(CreateLang.translate("gui.factory_panel.left_click_reset")
                                    .style(ChatFormatting.DARK_GRAY).style(ChatFormatting.ITALIC).component())
                            .build();
                }).onClick(button -> {
            sendConfig(true, false);
            playClickSound();
            return true;
        }));
        addRenderableWidget(new InteractiveAreaWidget(
                panelX + PROMISE_LIMIT_X, panelY + PANEL_H - 24, PROMISE_LIMIT_W, 16,
                () -> TooltipBuilder.of(font)
                        .line(Component.translatable("createfactorycontroller.gui.open_requests.title")
                                .withStyle(net.minecraft.network.chat.Style.EMPTY.withColor(ScrollInput.HEADER_RGB.getRGB())))
                        .wrapped(Component.translatable("createfactorycontroller.gui.open_requests.desc")
                                .withStyle(ChatFormatting.GRAY))
                        .empty()
                        .line(Component.translatable("createfactorycontroller.gui.open_requests.count_header")
                                .withColor(0xb88218))
                        .selector(Component.translatable("createfactorycontroller.gui.open_requests.scope_gauge"),
                                !promiseLimitByAddress)
                        .selector(Component.translatable("createfactorycontroller.gui.open_requests.scope_address"),
                                promiseLimitByAddress)
                        .line(Component.translatable("createfactorycontroller.gui.open_requests.scroll_limit")
                                .withStyle(ChatFormatting.DARK_GRAY, ChatFormatting.ITALIC))
                        .line(Component.translatable("createfactorycontroller.gui.open_requests.click_scope")
                                .withStyle(ChatFormatting.DARK_GRAY, ChatFormatting.ITALIC))
                        .build()).onClick(button -> {
            promiseLimitByAddress = !promiseLimitByAddress;
            playClickSound();
            return true;
        }).onScroll((scrollX, scrollY) -> {
            int dir = (int) Math.signum(scrollY);
            if (dir != 0) {
                int step = hasShiftDown() ? 10 : 1;
                promiseLimitState = Mth.clamp(promiseLimitState + dir * step, 0, 99);
                playScrollSound();
            }
            return true;
        }));
        countArea = addRenderableWidget(new InteractiveAreaWidget(
                panelX + COUNT_X, panelY + THRESH_TOP - 1, COUNT_W, THRESH_H,
                () -> {
                    VirtualGaugeBehaviour behaviour = getBehaviour();
                    Component title = Component.translatable(requestMode.isPassive()
                                    ? "createfactorycontroller.gui.threshold.minimum_target"
                                    : "createfactorycontroller.gui.threshold.stock_target")
                            .withColor(ScrollInput.HEADER_RGB.getRGB());
                    if (behaviour != null && behaviour.isNumberManaged())
                        return TooltipBuilder.of(font)
                                .line(title)
                                .line(Component.translatable("createfactorycontroller.gui.threshold.auto_managed_by_number")
                                        .withStyle(ChatFormatting.DARK_GRAY, ChatFormatting.ITALIC))
                                .build();
                    TooltipBuilder lines = TooltipBuilder.of(font).line(title);
                    if (behaviour != null && requestMode.isPassive() && g != null) {
                        String targetCount = behaviour.unit.format(g.getPassiveTargetCount(), true);
                        lines.line(Component.translatable("createfactorycontroller.gui.threshold.minimum_target.hint",
                                        Component.literal(targetCount).withColor(0x9ECFFC))
                                .withStyle(ChatFormatting.GRAY));
                    }
                    return lines.line(CreateLang.translate("gui.scrollInput.scrollToModify")
                                    .style(ChatFormatting.DARK_GRAY).style(ChatFormatting.ITALIC).component())
                            .line(CreateLang.translate("gui.scrollInput.shiftScrollsFaster")
                                    .style(ChatFormatting.DARK_GRAY).style(ChatFormatting.ITALIC).component())
                            .build();
                }).onClick(button -> {
            if (button != 0 && button != 1) return false;
            if (numberManaged()) return true;
            countEditing = true;
            countEdit = thresholdCount == 0 || button == 1 ? "" : String.valueOf(thresholdCount);
            setFocused(null);
            playClickSound();
            return true;
        }).onScroll((scrollX, scrollY) -> {
            if (numberManaged()) return true;
            if (countEditing) commitCountEdit();
            int dir = (int) Math.signum(scrollY);
            int step = hasControlDown() ? 100 : hasShiftDown() ? 10 : 1;
            thresholdCount = Mth.clamp(thresholdCount + dir * step, 0, mode.getMaxRequestCount());
            playScrollSound();
            return true;
        }));
        addRenderableWidget(new InteractiveAreaWidget(
                panelX + UNIT_X, panelY + THRESH_TOP - 1, UNIT_W, THRESH_H,
                () -> {
                    ThresholdUnit a = fluidMode ? ThresholdUnit.FLUID_MB : ThresholdUnit.ITEMS;
                    ThresholdUnit b = fluidMode ? ThresholdUnit.FLUID_BUCKET : ThresholdUnit.STACKS;
                    return TooltipBuilder.of(font)
                            .line(CreateLang.translate("schedule.condition.threshold.item_measure")
                                    .color(ScrollInput.HEADER_RGB).component())
                            .line(a.tooltipLine(mode == a))
                            .line(b.tooltipLine(mode == b))
                            .line(CreateLang.translate("gui.scrollInput.scrollToSelect")
                                    .style(ChatFormatting.DARK_GRAY).style(ChatFormatting.ITALIC).component())
                            .build();
                }).onClick(button -> {
            setMode(mode.cycle(1));
            return true;
        }).onScroll((scrollX, scrollY) -> {
            int dir = (int) Math.signum(scrollY);
            if (dir != 0) setMode(mode.cycle(-dir));
            return true;
        }));
        addRenderableWidget(new InteractiveAreaWidget(panelX + FILTER_X, panelY + THRESH_TOP, 16, 16,
                () -> {
                    VirtualGaugeBehaviour behaviour = getBehaviour();
                    if (behaviour == null) return List.of();
                    if (behaviour.filter.isEmpty())
                        return TooltipBuilder.of(font)
                                .line(CreateLang.translate("gui.factory_panel.unconfigured_input")
                                        .color(ScrollInput.HEADER_RGB).component())
                                .build();
                    return TooltipBuilder.of(font)
                            .lines(FluidCompat.isFluidFilter(behaviour.filter)
                                    ? FluidCompat.fluidTooltip(FluidCompat.getFilterFluid(behaviour.filter),
                                            Minecraft.getInstance().options.advancedItemTooltips)
                                    : getTooltipFromItem(Minecraft.getInstance(), behaviour.filter))
                            .build();
                }));
        ingredientArea = addRenderableWidget(editor().createInputAreaWidget());

        GaugeInfoClient.clear();   // drop any stale count; the next tick polls fresh
        promiseInfoPollCooldown = 0;
    }

    /** The button icon for each request mode. */
    private static ScreenElement iconFor(RequestMode mode) {
        String sprite = switch (mode) {
            case NORMAL -> "icons/set_target";
            case PASSIVE -> "icons/follows_demand";
            case PASSIVE_AND_ALLOW_ORDER -> "icons/follows_demand_with_order";
        };
        ResourceLocation loc = ResourceLocation.fromNamespaceAndPath(CreateFactoryController.MODID, sprite);
        return (gfx, x, y) -> gfx.blitSprite(loc, x, y, 16, 16);
    }

    @Override
    public void resize(@NotNull Minecraft minecraft, int width, int height) {
        controller.resize(minecraft, width, height);
        super.resize(minecraft, width, height);
    }

    @Override
    protected void containerTick() {
        super.containerTick();
        addressBox.tick();
        controller.tickComponentWidgets();
        // Poll the gauge's live in-flight promise counts every 10 ticks for the promise-limit box
        if (--promiseInfoPollCooldown <= 0) {
            promiseInfoPollCooldown = 10;
            PacketDistributor.sendToServer(new RequestGaugePromiseInfoPacket(menu.controllerPos, gaugePos));
        }
    }

    // ── State ────────────────────────────────────────────────────────────────

    @Nullable
    private VirtualGaugeBehaviour getBehaviour() {
        return menu.componentAt(gaugePos) instanceof VirtualGaugeBehaviour g ? g : null;
    }

    /** Whether the request-amount input is locked because a Number Connection is driving the target. */
    private boolean numberManaged() {
        VirtualGaugeBehaviour g = getBehaviour();
        return g != null && g.isNumberManaged();
    }

    ItemStack ingredientOf(VirtualComponentPosition pos) {
        return menu.componentAt(pos) instanceof VirtualGaugeBehaviour g ? g.filter : ItemStack.EMPTY;
    }

    /** Whether input connection {@code c}'s ingredient is a fluid */
    boolean isFluidConn(int c) {
        return FluidCompat.isFluidFilter(ingredientOf(inputConnections.get(c)));
    }

    boolean multiplierExcluded(VirtualComponentPosition source) {
        return workMode != GaugeWorkMode.CRAFTING && multiplierExcludedInputs.contains(source);
    }

    /** Per-ingredient millibucket cap — one grid cell of a fluid ingredient. */
    static final int FLUID_INGREDIENT_CAP_MB = VirtualGaugeBehaviour.FLUID_INGREDIENT_CAP_MB;

    /** A grid slot's source: which input connection it belongs to, and how many items sit in it. */
    record InputSlot(int connectionIndex, int amount) {}

    static int stackSizeOf(ItemStack stack) {
        return stack.isEmpty() ? 1 : Math.max(1, stack.getMaxStackSize());
    }

    /**
     * Lays the input connections out into grid slots: each connection fills full stacks first then a single
     * partial last slot (so no slot exceeds the item's stack size), its slots contiguous, connections packed
     * in order — capped at {@link #MAX_INPUT_SLOTS}. Recomputed wherever the grid is drawn or hit-tested.
     */
    List<InputSlot> layoutInputSlots() { return layoutInputSlots(1); }

    /** As {@link #layoutInputSlots()} but every connection total is first multiplied by {@code scale} (the
     *  request-multiplier preview): the scaled totals re-pack into full stacks + a partial, so a scaled demand
     *  naturally spills across more grid slots. */
    List<InputSlot> layoutInputSlots(int scale) {
        int s = Math.max(1, scale);
        List<InputSlot> slots = new ArrayList<>();
        for (int c = 0; c < inputConnections.size() && slots.size() < MAX_INPUT_SLOTS; c++) {
            int factor = multiplierExcluded(inputConnections.get(c)) ? 1 : s;
            int total = Math.max(1, inputTotals.get(c)) * factor;
            if (isFluidConn(c)) {
                slots.add(new InputSlot(c, total));
                continue;
            }
            int ss = stackSizeOf(ingredientOf(inputConnections.get(c)));
            int remaining = total;
            do {
                if (slots.size() >= MAX_INPUT_SLOTS) return slots;
                int amt = Math.min(ss, remaining);
                slots.add(new InputSlot(c, amt));
                remaining -= amt;
            } while (remaining > 0);
        }
        return slots;
    }

    /** Slots used by every connection except {@code exceptIndex}. */
    int slotsUsedExcept(int exceptIndex) {
        int used = 0;
        for (int c = 0; c < inputConnections.size(); c++) {
            if (c == exceptIndex) continue;
            if (isFluidConn(c)) { used += 1; continue; }     // fluid ingredient = one slot
            int ss = stackSizeOf(ingredientOf(inputConnections.get(c)));
            int total = Math.max(1, inputTotals.get(c));
            used += (total + ss - 1) / ss;   // ceil
        }
        return used;
    }

    /** Disconnects the ingredient connection at {@code connectionIndex} */
    void disconnectInput(int connectionIndex) {
        VirtualComponentPosition from = inputConnections.get(connectionIndex);
        inputConnections.remove(connectionIndex);
        inputTotals.remove(connectionIndex);
        inputConfig.remove(connectionIndex);
        multiplierExcludedInputs.remove(from);
        PacketDistributor.sendToServer(new DisconnectIngredientPacket(menu.controllerPos, from, gaugePos));
        onConnectionsChanged();
        playClickSound();
    }

    /**
     * Scrolls a connection's total (shared by all its slots): plain ±1 item, shift ±10 (snapping to the
     * next stack-size boundary when it would otherwise cross one from a non-boundary start), ctrl ±1 full
     * stack. Clamped to ≥1 and to the item count that still fits the free grid slots.
     */
    void adjustInputTotal(int connectionIndex, int dir, boolean shift, boolean ctrl) {
        if (isFluidConn(connectionIndex)) {              // fluid ingredient: millibuckets, fluid steps, one slot
            int curMb = Math.max(1, inputTotals.get(connectionIndex));
            inputTotals.set(connectionIndex, adjustFluidAmount(curMb, dir, shift, ctrl, 1, FLUID_INGREDIENT_CAP_MB));
            return;
        }
        int ss = stackSizeOf(ingredientOf(inputConnections.get(connectionIndex)));
        int cur = Math.max(1, inputTotals.get(connectionIndex));

        int maxSlots = Math.max(1, MAX_INPUT_SLOTS - slotsUsedExcept(connectionIndex));
        int maxTotal = maxSlots * ss;

        int next;
        if (ctrl) {
            next = snapToStack(cur, dir, ss);            // snap to the next/previous full-stack value
        } else if (shift) {
            next = shiftStep(cur, dir, ss);              // ±10, snapping across a stack boundary
        } else {
            next = cur + dir;                            // ±1 item
        }
        inputTotals.set(connectionIndex, Mth.clamp(next, 1, maxTotal));
    }

    private int maxCraftBatch() {
        return Math.max(1, MAX_CRAFT_OUTPUT);
    }

    /** Max stack size of the produced item (64 when no filter yet). */
    int outputStackSize() {
        VirtualGaugeBehaviour g = getBehaviour();
        return g == null || g.filter.isEmpty() ? 64 : Math.max(1, g.filter.getMaxStackSize());
    }

    /** Largest free (non-crafting) item output count */
    int maxItemOutput() {
        return Math.max(64, 64 * outputStackSize());
    }

    /** The request-multiplier ceiling this gauge's current edit state structurally allows (ignores stock).
     *  Mirrors {@link VirtualGaugeBehaviour#structuralMultiplierCap()} using the screen's edit state. */
    int structuralMultiplierCap() {
        if (workMode == GaugeWorkMode.CRAFTING)
            return VirtualGaugeBehaviour.craftingMultiplierCap(effectiveBatch(), 64);

        int outputCap = fluidMode ? VirtualGaugeBehaviour.FLUID_OUTPUT_CAP_MB : maxItemOutput();
        int output = Math.max(1, outputCount);
        List<VirtualGaugeBehaviour.ScaleSlot> slots = new ArrayList<>();
        if (workMode == GaugeWorkMode.CUSTOM) {
            for (RecipeSlot rs : customSlots) {
                if (rs.isEmpty()) continue;
                ItemStack ing = ingredientOf(rs.source());
                if (ing.isEmpty()) continue;
                boolean fluid = FluidCompat.isFluidFilter(ing);
                int capacity = fluid ? FLUID_INGREDIENT_CAP_MB : stackSizeOf(ing);
                slots.add(new VirtualGaugeBehaviour.ScaleSlot(Math.max(1, rs.count()), capacity, fluid,
                    multiplierExcluded(rs.source())));
            }
            return VirtualGaugeBehaviour.customMultiplierCap(slots, output, outputCap, 64);
        }
        // REGULAR: one entry per ingredient connection (its whole total).
        for (int c = 0; c < inputConnections.size(); c++) {
            boolean fluid = isFluidConn(c);
            int capacity = fluid ? FLUID_INGREDIENT_CAP_MB : stackSizeOf(ingredientOf(inputConnections.get(c)));
            slots.add(new VirtualGaugeBehaviour.ScaleSlot(Math.max(1, inputTotals.get(c)), capacity, fluid,
                multiplierExcluded(inputConnections.get(c))));
        }
        return VirtualGaugeBehaviour.regularMultiplierCap(slots, output, outputCap, 64);
    }

    /** Whether {@code (mx, my)} is over the request-multiplier bar. */
    boolean overMultiplier(double mx, double my) {
        return multiplierArea != null && multiplierArea.isMouseOver(mx, my);
    }

    /** The interval currently shown on the arrow, in whole seconds. */
    private int shownIntervalSeconds() {
        return customRequestTimer > 0 ? customRequestTimer / TICKS_PER_SEC : Math.max(1,
                Math.round(AllConfigs.server().logistics.factoryGaugeTimer.get() / (float) TICKS_PER_SEC));
    }

    private void setRequestInterval(int ticks) {
        customRequestTimer = ticks;
        PacketDistributor.sendToServer(new SetGaugeRequestIntervalPacket(menu.controllerPos, gaugePos, ticks));
    }

    /** Scale to render the ingredient/output amounts at for the given cursor: the multiplier while its bar is
     *  hovered, else 1. A per-frame derived value (every render method gets the same cursor), so no cached field. */
    int previewScale(double mx, double my) {
        return overMultiplier(mx, my) ? maxRequestMultiplier : 1;
    }

    static MutableComponent stackBreakdown(int count, int ss) {
        int stacks = count / ss, overflow = count % ss;
        return Component.literal(" | " + stacks + "▤" + (overflow > 0 ? " +" + overflow : ""))
                .withStyle(ChatFormatting.DARK_GRAY);
    }

    /** Ctrl-scroll snap: move {@code cur} to the next full-stack multiple of {@code ss} in direction {@code dir} —
     *  up rounds to the next higher multiple, down to the next lower. */
    static int snapToStack(int cur, int dir, int ss) {
        return dir > 0 ? (cur / ss + 1) * ss : (cur - 1) / ss * ss;
    }

    /** Shift-scroll step: {@code cur ± 10}, but snapped to the stack boundary it would cross when {@code cur} isn't
     *  already on one (so shift-scrolling lands cleanly on stack multiples). */
    static int shiftStep(int cur, int dir, int ss) {
        int next = cur + dir * 10;
        if (cur % ss != 0) {
            int boundary = dir > 0 ? (cur / ss + 1) * ss : (cur / ss) * ss;
            if (dir > 0 ? next > boundary : next < boundary) next = boundary;
        }
        return next;
    }

    /** Crafts per request actually used. Ignore-data ingredients still batch — each slot ships a single variant
     *  covering its whole batch (server-resolved). */
    int effectiveBatch() {
        return Math.max(1, craftBatch);
    }

    /** Crafting mode: change crafts-per-request, capped so the produced output stays within one stack. */
    void adjustCraftBatch(int delta) {
        int next = Mth.clamp(craftBatch + delta, 1, maxCraftBatch());
        if (next != craftBatch) {
            craftBatch = next;
            playScrollSound();
        }
    }

    /**
     * Ctrl-scroll over the recipe's ingredients: resize the square crafter grid, between the recipe's minimum
     * bounding square and the configured maximum ({@link ServerConfig#maxCraftGridSize()}).
     */
    void adjustCraftDimension(int dir) {
        int next = Mth.clamp(effectiveCraftDimension() + dir, minCraftDim(), maxCraftDim(defaultCraftDim()));
        if (next != craftDimension) {
            craftDimension = next;
            craftingIngredients = buildSquareArrangement(craftDimension);
            playScrollSound();
        }
    }

    /** Upper bound for the crafter-grid size */
    private static int maxCraftDim(int defaultDim) {
        return Math.max(defaultDim, ServerConfig.maxCraftGridSize());
    }

    /** One drawn cell of the aggregated crafting view: an ingredient and how many sit in this grid slot. */
    record CraftSlot(ItemStack stack, int amount) {}

    /**
     * Collapses the recipe arrangement into its distinct ingredient types (first-appearance order) and the
     * total cell-count each uses. Aggregating by item means a recipe that reuses one ingredient across many
     * cells (most recipes) needs only one type slot — the key to showing a &gt;3×3 recipe in the 3×3 grid.
     */
    private void craftingTypeAggregate(List<ItemStack> typesOut, List<Integer> cellsOut) {
        for (BigItemStack b : craftingIngredients) {
            if (b.stack.isEmpty()) continue;
            int amt = Math.max(1, b.stack.getCount());
            int idx = -1;
            for (int i = 0; i < typesOut.size(); i++)
                if (ItemStack.isSameItemSameComponents(typesOut.get(i), b.stack)) { idx = i; break; }
            if (idx < 0) { typesOut.add(b.stack); cellsOut.add(amt); }
            else cellsOut.set(idx, cellsOut.get(idx) + amt);
        }
    }

    /**
     * The aggregated grid view of a large (&gt;3×3) crafting recipe: one slot per distinct ingredient type,
     * its amount being the type's total usage (cells × batch). Crafting slots never overflow into a second
     * slot, so a count above the item's stack size simply shows as a large number in the one slot. Display
     * only — the dispatched package still carries the real N×M arrangement.
     */
    List<CraftSlot> craftingDisplaySlots() {
        List<ItemStack> types = new ArrayList<>();
        List<Integer> cells = new ArrayList<>();
        craftingTypeAggregate(types, cells);
        List<CraftSlot> slots = new ArrayList<>();
        int batch = effectiveBatch();
        for (int t = 0; t < types.size() && slots.size() < MAX_INPUT_SLOTS; t++)
            slots.add(new CraftSlot(types.get(t), cells.get(t) * batch));
        return slots;
    }

    /**
     * Whether one craft fits a single 9-slot package: each distinct ingredient type occupies exactly one slot
     * (no stack-size overflow), and batch is irrelevant because re-packaging splits a multi-craft order into
     * one package per craft. A recipe with &gt;9 distinct types can't be packaged at all.
     */
    private boolean craftingFitsPackage() {
        List<ItemStack> types = new ArrayList<>();
        List<Integer> cells = new ArrayList<>();
        craftingTypeAggregate(types, cells);
        return types.size() <= MAX_INPUT_SLOTS;
    }

    /** True when the recipe is larger than 3×3 (shaped width or height &gt; 3) — the aggregated/Ctrl path. */
    boolean craftingIsLarge() {
        return availableCraftingRecipe instanceof ShapedRecipe s && (s.getWidth() > 3 || s.getHeight() > 3);
    }

    /** Smallest square crafter grid the recipe can be fit */
    private int minCraftDim() {
        return Math.max(1, Math.max(craftingPatternWidth(), craftingPatternHeight()));
    }

    /** 3x3, unless larger craft */
    private int defaultCraftDim() {
        return Math.max(3, minCraftDim());
    }

    /** The square grid size a recipe could fit */
    int effectiveCraftDimension() {
        int dim = craftDimension <= 0 ? defaultCraftDim() : craftDimension;   // 0 = unset
        return Mth.clamp(dim, minCraftDim(), maxCraftDim(defaultCraftDim()));
    }

    /** The crafting toggle's tooltip: the activate hint, plus the current N×N grid size. Rendered last (in
     *  {@link #renderForeground}) so a later-drawn neighbouring widget can't paint over it. */
    private List<FormattedCharSequence> craftingButtonTooltip() {
        TooltipBuilder tip = TooltipBuilder.of(font)
                .line(CreateLang.translate("gui.factory_panel.activate_crafting").component());
        if (availableCraftingRecipe != null) {
            int dim = effectiveCraftDimension();
            tip.line(Component.translatable("createfactorycontroller.gui.crafting_dimension", dim, dim)
                .withStyle(ChatFormatting.GRAY));
        }
        if (craftingUsesIgnoreData()) {
            tip.empty();
            tip.wrapped(Component.translatable("createfactorycontroller.gui.ingredient_ignore_data_tip")
                .withStyle(ChatFormatting.GOLD));
        }
        return tip.build();
    }

    /** The custom-arrangement toggle's tooltip. Rendered last (in {@link #renderForeground}) so a later-drawn
     *  neighbouring widget can't paint over it. */
    private List<FormattedCharSequence> customButtonTooltip() {
        TooltipBuilder tip = TooltipBuilder.of(font)
                .line(Component.translatable("createfactorycontroller.gui.custom_arrangement"))
                .line(Component.translatable("createfactorycontroller.gui.custom_arrangement.tip")
                        .withStyle(ChatFormatting.GRAY));
        if (craftingUsesIgnoreData()) {
            tip.empty();
            tip.wrapped(Component.translatable("createfactorycontroller.gui.ingredient_ignore_data_tip")
                .withStyle(ChatFormatting.GOLD));
        }
        return tip.build();
    }

    private List<FormattedCharSequence> requestModeButtonTooltip() {
        TooltipBuilder lines = TooltipBuilder.of(font)
                .line(Component.translatable("createfactorycontroller.gui.request_mode")
                        .withStyle(net.minecraft.network.chat.Style.EMPTY.withColor(ScrollInput.HEADER_RGB.getRGB())));
        for (RequestMode m : RequestMode.values()) {
            lines.selector(Component.translatable(m.translationKey), m == requestMode);
        }
        return lines.wrapped(Component.translatable(requestMode.translationKey + ".desc")
                        .withColor(TooltipBuilder.SELECTOR_DESCRIPTION_COLOR))
                .line(Component.translatable("createfactorycontroller.gui.request_mode.change_tip")
                        .withStyle(ChatFormatting.DARK_GRAY, ChatFormatting.ITALIC))
                .build();
    }

    private void updateConfigs() {
        inputConnections.clear();
        inputTotals.clear();
        inputConfig.clear();
        multiplierExcludedInputs.clear();
        VirtualGaugeBehaviour g = getBehaviour();
        if (g == null) return;
        outputCount = Math.max(1, g.recipeOutput);
        craftBatch = Math.max(1, g.craftBatch);
        maxRequestMultiplier = Math.max(1, g.maxRequestMultiplier);
        customRequestTimer = Math.max(0, g.customRequestTimer);
        craftDimension = Math.max(0, g.craftDimension);
        thresholdCount = Math.max(0, g.count);
        mode = g.unit;
        requestMode = g.requestMode;
        promiseLimitState = g.promiseLimit;
        promiseLimitByAddress = g.promiseLimitByAddress;
        fluidMode = FluidCompat.isFluidFilter(g.filter);
        if (fluidMode && !mode.isFluid()) mode = ThresholdUnit.FLUID_BUCKET;
        if (!fluidMode && mode.isFluid()) mode = ThresholdUnit.ITEMS;
        if (fluidMode && outputCount <= 1) outputCount = 1000;
        for (Connection conn : g.incomingConnections()) {
            if (!(conn instanceof LogisticsConnection lc)) continue;
            int total = lc.amount();
            inputConnections.add(conn.from);
            inputTotals.add(total);
            inputConfig.add(new BigItemStack(ingredientOf(conn.from), total));
            if (g.mode != GaugeWorkMode.CRAFTING && lc.excludeFromRequestMultiplier)
                multiplierExcludedInputs.add(conn.from);
        }

        workMode = g.mode;
        customSlots = new ArrayList<>(java.util.Collections.nCopies(MAX_INPUT_SLOTS, RecipeSlot.EMPTY));
        if (g.mode == GaugeWorkMode.CUSTOM) {
            for (int i = 0; i < g.recipeSlots.size() && i < MAX_INPUT_SLOTS; i++)
                customSlots.set(i, g.recipeSlots.get(i));
            reconcileCustomSlots();   // pick up wires added/removed since the layout was last saved
        }
        searchForCraftingRecipe();
        applyCraftingResolution();
        maxRequestMultiplier = Mth.clamp(maxRequestMultiplier, 1, structuralMultiplierCap());
    }

    /** Reconciles {@link #customSlots} with the live ingredient connections: drops slots whose wire is gone,
     *  and drops each newly-added wire into the first free slot (respecting the 9-slot grid cap). */
    void reconcileCustomSlots() {
        while (customSlots.size() < MAX_INPUT_SLOTS) customSlots.add(RecipeSlot.EMPTY);
        for (int i = 0; i < customSlots.size(); i++) {
            RecipeSlot slot = customSlots.get(i);
            if (!slot.isEmpty() && !inputConnections.contains(slot.source()))
                customSlots.set(i, RecipeSlot.EMPTY);   // its wire was removed
        }
        for (int c = 0; c < inputConnections.size(); c++) {
            VirtualComponentPosition src = inputConnections.get(c);
            if (customSlots.stream().anyMatch(sl -> !sl.isEmpty() && src.equals(sl.source()))) continue;
            int empty = -1;
            for (int i = 0; i < customSlots.size(); i++) if (customSlots.get(i).isEmpty()) { empty = i; break; }
            if (empty < 0) break;   // grid full — the extra wire stays unplaced
            // One cell holds at most a stack of the item; a fluid ingredient's cell carries mB up to the cap.
            int cap = isFluidConn(c) ? FLUID_INGREDIENT_CAP_MB : Math.max(1, stackSizeOf(ingredientOf(src)));
            customSlots.set(empty, new RecipeSlot(src, Math.clamp(inputTotals.get(c), 1, cap)));
        }
    }

    /**
     * After {@link #searchForCraftingRecipe}, lays the recipe into a square crafter grid, locks the output to
     * the recipe yield, and enforces the package-fit gate (a recipe with &gt;9 distinct ingredient types can't
     * be packaged, so it's rejected). The square (default = the recipe's minimum bounding square, restored from
     * the gauge or Ctrl-scrollable) is what we dispatch, so the flat pattern maps cell-for-cell onto an N×N
     * mechanical-crafter array — fixing the misalignment Create's 3-wide package layout caused.
     */
    void applyCraftingResolution() {
        if (availableCraftingRecipe == null) {
            if (workMode == GaugeWorkMode.CRAFTING) workMode = GaugeWorkMode.REGULAR;
            craftingIngredients = new ArrayList<>();
            craftDimension = 0;
            return;
        }
        if (workMode != GaugeWorkMode.CRAFTING) return;
        lockOutputToRecipe();
        craftDimension = effectiveCraftDimension();
        craftingIngredients = buildSquareArrangement(craftDimension);
        if (!craftingFitsPackage()) {
            workMode = GaugeWorkMode.REGULAR;
            availableCraftingRecipe = null;
            craftingIngredients = new ArrayList<>();
            craftDimension = 0;
            return;
        }
        craftBatch = Mth.clamp(craftBatch, 1, maxCraftBatch());
    }

    /**
     * Resolves a recipe cell's ingredient to the connected input stack that satisfies it (count 1), so the
     * dispatched pattern matches the items the package box will carry; an empty cell stays empty.
     */
    private ItemStack resolveCraftCell(Ingredient ing) {
        if (ing.isEmpty()) return ItemStack.EMPTY;
        for (BigItemStack b : inputConfig)
            if (!b.stack.isEmpty() && ing.test(b.stack)) return b.stack.copyWithCount(1);
        ItemStack[] items = ing.getItems();
        return items.length > 0 ? items[0].copyWithCount(1) : ItemStack.EMPTY;
    }

    /**
     * Lays the recipe's true W×H ingredients into a {@code dim×dim} grid (row-major), the rest empty — the
     * pattern that maps cell-for-cell onto a dim×dim mechanical-crafter array on unpacking.
     *
     * <p>A ≤3×3 recipe is centred within the top-left 3×3 block (matching Create's factory-panel layout, e.g.
     * a vertical stick at top-middle + centre, not the corner); larger recipes anchor at the top-left corner.
     * Centring inside the fixed 3×3 block (rather than the whole grid) keeps the recipe in the same on-screen
     * slots when the grid is scrolled larger.</p>
     */
    private List<BigItemStack> buildSquareArrangement(int dim) {
        List<BigItemStack> out = new ArrayList<>(dim * dim);
        int w = craftingPatternWidth(), h = craftingPatternHeight();
        assert availableCraftingRecipe != null;
        var ingredients = availableCraftingRecipe.getIngredients();
        int block = Math.min(3, dim);
        int colOff = craftingIsLarge() ? 0 : (block - w) / 2;
        int rowOff = craftingIsLarge() ? 0 : (block - h) / 2;
        for (int r = 0; r < dim; r++)
            for (int c = 0; c < dim; c++) {
                int rr = r - rowOff, cc = c - colOff;
                ItemStack s = (rr >= 0 && rr < h && cc >= 0 && cc < w && rr * w + cc < ingredients.size())
                    ? resolveCraftCell(ingredients.get(rr * w + cc)) : ItemStack.EMPTY;
                out.add(new BigItemStack(s, 1));
            }
        return out;
    }

    /** In crafting mode the output count is fixed to the recipe's yield (not user-scrollable). */
    private void lockOutputToRecipe() {
        ClientLevel level = Minecraft.getInstance().level;
        if (availableCraftingRecipe != null && level != null)
            outputCount = availableCraftingRecipe.getResultItem(level.registryAccess()).getCount();
    }

    /** Re-evaluates crafting availability after the input connections change, then rebuilds the layout. */
    private void onConnectionsChanged() {
        searchForCraftingRecipe();
        applyCraftingResolution();
        rebuildWidgets();   // clears + re-runs init(); button appears/disappears with availability
    }

    /** Reimplements Create's FactoryPanelScreen#searchForCraftingRecipe for gauge's inputs/output. */
    private void searchForCraftingRecipe() {
        availableCraftingRecipe = null;
        VirtualGaugeBehaviour g = getBehaviour();
        if (g == null || g.filter.isEmpty() || inputConfig.isEmpty()) return;

        ItemStack output = g.filter;
        Set<Item> itemsToUse = inputConfig.stream()
            .map(b -> b.stack).filter(i -> !i.isEmpty()).map(ItemStack::getItem).collect(Collectors.toSet());

        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) return;

        availableCraftingRecipe = matchCraftingRecipe(level, output, itemsToUse, RecipeType.CRAFTING);
        if (availableCraftingRecipe == null) {
            RecipeType<MechanicalCraftingRecipe> mechanical = AllRecipeTypes.MECHANICAL_CRAFTING.getType();
            availableCraftingRecipe = matchCraftingRecipe(level, output, itemsToUse, mechanical);
        }
    }

    /** Whether any wired ingredient ignores item data — crafting then ships a single in-stock variant per such
     *  ingredient per request (see the server-side pinning). */
    boolean craftingUsesIgnoreData() {
        for (VirtualComponentPosition pos : inputConnections)
            if (menu.componentAt(pos) instanceof VirtualGaugeBehaviour s && s.ignoreData) return true;
        return false;
    }

    /** Whether a crafting-grid cell's ingredient is supplied by an ignore-data gauge (its shipped variant is
     *  resolved per request) — drives the per-slot "Ignore Data" tooltip line. Matches the server's cell→source
     *  resolution ({@code isSameItemSameComponents} against the gauge filter). */
    boolean craftingCellIgnoresData(ItemStack cell) {
        if (cell.isEmpty()) return false;
        for (VirtualComponentPosition pos : inputConnections)
            if (menu.componentAt(pos) instanceof VirtualGaugeBehaviour s
                    && s.ignoreData && !s.filter.isEmpty()
                    && ItemStack.isSameItemSameComponents(s.filter, cell))
                return true;
        return false;
    }

    /**
     * Finds a recipe of {@code type} that produces {@code output} and whose every ingredient is covered by a
     * wired input (mirrors Create's {@code FactoryPanelScreen#searchForCraftingRecipe}). Generic over the
     * crafting recipe type so it serves both vanilla {@code CRAFTING} and Create's {@code MECHANICAL_CRAFTING}.
     */
    @Nullable
    private <T extends CraftingRecipe> CraftingRecipe matchCraftingRecipe(
            ClientLevel level, ItemStack output, Set<Item> itemsToUse, RecipeType<T> type) {
        return level.getRecipeManager()
            .getAllRecipesFor(type)
            .parallelStream()
            .filter(r -> output.getItem() == r.value().getResultItem(level.registryAccess()).getItem())
            // Reject recipes whose minimum crafter grid exceeds the configured maximum — they'd need a larger
            // crafter array than allowed, so crafting mode is simply unavailable for them
            .filter(r -> recipeFitsConfiguredGrid(r.value()))
            .filter(r -> {
                if (AllRecipeTypes.shouldIgnoreInAutomation(r)) return false;
                Set<Item> itemsUsed = new HashSet<>();
                for (Ingredient ingredient : r.value().getIngredients()) {
                    if (ingredient.isEmpty()) continue;
                    boolean available = false;
                    for (BigItemStack bis : inputConfig)
                        if (!bis.stack.isEmpty() && ingredient.test(bis.stack)) {
                            available = true;
                            itemsUsed.add(bis.stack.getItem());
                            break;
                        }
                    if (!available) return false;
                }
                return itemsUsed.size() >= itemsToUse.size();
            })
            .findAny()
            .<CraftingRecipe>map(RecipeHolder::value)
            .orElse(null);
    }

    /** Whether a recipe's minimum bounding square (≥3) fits the configured maximum crafter-grid size. Only
     *  shaped recipes can exceed 3×3; anything else is at most 3×3 and always fits. */
    private static boolean recipeFitsConfiguredGrid(CraftingRecipe r) {
        int min = r instanceof ShapedRecipe s ? Math.max(3, Math.max(s.getWidth(), s.getHeight())) : 3;
        return min <= ServerConfig.maxCraftGridSize();
    }

    @Override
    public FactoryControllerScreen boardScreen() {
        return controller;
    }

    @Override
    public void onPanelSync() {
        controller.onPanelSync();
    }

    // ── Render ─────────────────────────────────────────────────────────────

    @Override
    public void render(GuiGraphics gfx, int mouseX, int mouseY, float partialTick) {
        super.render(gfx, mouseX, mouseY, partialTick);
        if (patternHovered) renderCraftingPattern(gfx, mouseX, mouseY);   // Ctrl-held layout, drawn on top
        editor().renderOverlay(gfx, mouseX, mouseY);   // drag preview (custom mode), above all grid items/font
        renderTooltip(gfx, mouseX, mouseY);
        helpButton.renderTooltip(gfx, font, mouseX, mouseY);
    }

    private int craftingPatternWidth() {
        if (availableCraftingRecipe instanceof ShapedRecipe shaped)
            return Math.max(1, shaped.getWidth());
        if (availableCraftingRecipe == null) return 1;
        return Math.clamp(availableCraftingRecipe.getIngredients().size(), 1, 3);
    }

    private int craftingPatternHeight() {
        if (availableCraftingRecipe instanceof ShapedRecipe shaped)
            return Math.max(1, shaped.getHeight());
        if (availableCraftingRecipe == null) return 1;
        return Math.min(3, availableCraftingRecipe.getIngredients().size() / 3 + 1);
    }

    /**
     * Ctrl-held layout popup near the cursor: a header (with the current N×N grid size) and a scroll hint
     * above the recipe laid out in its dim×dim crafter grid (the exact pattern the package will unpack into,
     * read from {@link #craftingIngredients}). Ctrl-scrolling an ingredient resizes the grid live.
     */
    private void renderCraftingPattern(GuiGraphics gfx, int mouseX, int mouseY) {
        if (craftingIngredients.isEmpty()) return;
        int dim = effectiveCraftDimension();
        int cell = 17;
        int headerColor = 0xFF000000 | (ScrollInput.HEADER_RGB.getRGB() & 0xFFFFFF);   // blue, like tooltip headers
        Component l1 = Component.translatable("createfactorycontroller.gui.crafting_pattern", dim, dim);
        Component l2 = Component.translatable("createfactorycontroller.gui.crafting_scroll_dim")
            .withStyle(ChatFormatting.DARK_GRAY).withStyle(ChatFormatting.ITALIC);
        int gridSpan = dim * cell + 1;                    // include the closing grid line
        int textBlockH = font.lineHeight * 2 + 2;
        int gap = 3;
        int contentW = Math.max(gridSpan, Math.max(font.width(l1), font.width(l2)));
        int contentH = textBlockH + gap + gridSpan;
        // Place + clamp like a vanilla tooltip (content origin; the background border extends a few px out).
        int margin = 6;
        int cx = Mth.clamp(mouseX + 12, margin, Math.max(margin, width - contentW - margin));
        int cy = Mth.clamp(mouseY - 12, margin, Math.max(margin, height - contentH - margin));

        gfx.pose().pushPose();
        // Vanilla tooltip frame (gradient border + dark fill), then draw content above it at z 400.
        TooltipRenderUtil.renderTooltipBackground(gfx, cx, cy, contentW, contentH, 400);
        gfx.pose().translate(0, 0, 400);
        gfx.drawString(font, l1, cx, cy, headerColor, false);
        gfx.drawString(font, l2, cx, cy + font.lineHeight + 2, 0xFFA0A0A0, false);

        int gridX = cx, gridY = cy + textBlockH + gap;
        int lineColor = 0xFF556088;
        for (int k = 0; k <= dim; k++) {
            gfx.fill(gridX + k * cell, gridY, gridX + k * cell + 1, gridY + dim * cell, lineColor);   // verticals
            gfx.fill(gridX, gridY + k * cell, gridX + dim * cell + 1, gridY + k * cell + 1, lineColor); // horizontals
        }
        for (int i = 0; i < craftingIngredients.size(); i++) {
            ItemStack s = craftingIngredients.get(i).stack;
            if (s.isEmpty()) continue;
            gfx.renderItem(s, gridX + (i % dim) * cell + 1, gridY + (i / dim) * cell + 1);
        }
        gfx.pose().popPose();
    }

    @Override
    protected void renderBg(@NotNull GuiGraphics gfx, float partialTick, int mouseX, int mouseY) {
        controller.renderBoard(gfx, -1, -1, partialTick, true);

        RenderSystem.enableBlend();
        gfx.blit(PANEL_TEX, panelX, panelY, 0, 0, PANEL_W, PANEL_H, PANEL_W, PANEL_H);

        VirtualGaugeBehaviour g = getBehaviour();

        int multCap = structuralMultiplierCap();
        maxRequestMultiplier = Mth.clamp(maxRequestMultiplier, 1, multCap);
        boolean overMultiplier = overMultiplier(mouseX, mouseY);

        editor().renderInputArea(gfx, mouseX, mouseY);

        if (g != null && !g.filter.isEmpty()) {
            int ox = panelX + OUTPUT_X, oy = panelY + OUTPUT_Y;
            int producedCount = editor().producedCount();
            int shownOutput = producedCount * previewScale(mouseX, mouseY);
            ResourceIconRenderer.render(gfx, g.filter, ox, oy);
            drawItemCount(gfx, g.filter, ox, oy, fluidMode ? formatFluidShort(shownOutput) : String.valueOf(shownOutput));
            if (overMultiplier) {
                gfx.fill(panelX + MULTIPLIER_X, panelY + MULTIPLIER_Y,
                        panelX + MULTIPLIER_X + MULTIPLIER_W, panelY + MULTIPLIER_Y + MULTIPLIER_H,
                        0x55AAAAAA);
            }
            SpriteNumbersRender.drawCountRightAligned(gfx, SpriteNumbersRender.MULTIPLY + maxRequestMultiplier,
                    panelX + MULTIPLIER_X + MULTIPLIER_W + 2, panelY + MULTIPLIER_Y + MULTIPLIER_H - 6,
                    overMultiplier || maxRequestMultiplier > 1 ? MULTIPLIER_COLOR : MULTIPLIER_DISABLE_COLOR);

            if (overMultiplier) {
                gfx.pose().pushPose();
                gfx.pose().translate(0, 0, 199);
                editor().fillOccupiedCells(gfx, REQUEST_MULTIPLIER_COLOR);
                gfx.fill(ox, oy, ox + 16, oy + 16, REQUEST_MULTIPLIER_COLOR);
                gfx.pose().popPose();
            }
        }

        // Request-timer
        if (g != null && GaugeInfoClient.timerTicking(gaugePos)) {
            float progress = GaugeInfoClient.timerProgress(gaugePos, g.lastRequestTick);
            // floor(progress·FRAMES) so every frame — including frame 0 — gets an equal window
            int frame = Mth.clamp((int) (progress * ARROW_ANIM_FRAMES), 0, ARROW_ANIM_FRAMES - 1);
            RenderSystem.enableBlend();
            gfx.blit(ARROW_ANIM_TEX, panelX + ARROW_ANIM_X, panelY + ARROW_ANIM_Y, 0, frame * ARROW_ANIM_H,
                    ARROW_ANIM_W, ARROW_ANIM_H, ARROW_ANIM_W, ARROW_ANIM_FRAMES * ARROW_ANIM_H);
        }

        SpriteNumbersRender.drawCountRightAligned(gfx, SpriteNumbersRender.CLOCK + "·" + shownIntervalSeconds(),
                panelX + INTERVAL_RIGHT_X, panelY + INTERVAL_Y,
                customRequestTimer > 0 ? INTERVAL_CUSTOM_COLOR : INTERVAL_DISABLE_COLOR);

        renderThreshold(gfx, g);

        // Open-promise package box
        int pbx = panelX + PROMISE_CLEAR_X, pby = panelY + PANEL_H - 24;
        int promised = g == null ? 0 : g.promisedCount;
        String promisedLabel = g != null && FluidCompat.isFluidFilter(g.filter)
            ? formatFluidShort(promised) : String.valueOf(promised);
        ItemStack box = PackageStyles.getDefaultBox();
        gfx.renderItem(box, pbx, pby);
        drawItemCount(gfx, box, pbx, pby, (ClientConfig.compactRecipeCountFont() && promised > 0 ? "+": "")
                + promisedLabel);

        // 3D gauge preview
        GuiGameElement.of(g == null ? AllBlocks.FACTORY_GAUGE : g.getItem())
            .scale(4).at(0, 0, -200).render(gfx, panelX + 195, panelY + 139);
        if (g != null && !g.filter.isEmpty()) {
            if (FluidCompat.isFluidFilter(g.filter))
                FluidGuiRender.cube(gfx, FluidCompat.getFilterFluid(g.filter), panelX + 219, panelY + 157, 16);
            else
                GuiGameElement.of(g.filter).scale(1.625).at(0, 0, 100).render(gfx, panelX + 214, panelY + 152);
        }

        confirmButton.render(gfx, mouseX, mouseY, partialTick);
        helpButton.render(gfx, mouseX, mouseY, partialTick);
        deleteButton.render(gfx, mouseX, mouseY, partialTick);

        if (craftingButton != null) craftingButton.render(gfx, mouseX, mouseY, partialTick);
        customButton.render(gfx, mouseX, mouseY, partialTick);
        newInputButton.render(gfx, mouseX, mouseY, partialTick);
        relocateButton.render(gfx, mouseX, mouseY, partialTick);
        if (requestModeButton != null) requestModeButton.render(gfx, mouseX, mouseY, partialTick);

        promiseExpiration.render(gfx, mouseX, mouseY, partialTick);

        // Promise timeout
        int state = promiseExpiration.getState();
        String label = state == -1 ? "/" : state == 0 ? "30s" : state + "m";
        drawCenteredBoxLabel(gfx, promiseExpiration.getX(), promiseExpiration.getY(), promiseExpiration.getWidth(), label);

        int limit = promiseLimitState;
        // Live count polled from the server (on-demand), by the current scope; -1 until the first reply → show 0.
        int scoped = promiseLimitByAddress
            ? GaugeInfoClient.address(gaugePos) : GaugeInfoClient.owned(gaugePos);
        int activePromises = Math.max(0, scoped);
        drawPromiseLimitLabel(gfx, panelX + PROMISE_LIMIT_X, panelY + PANEL_H - 24, PROMISE_LIMIT_W,
            activePromises, limit, promiseLimitByAddress);

        // Non logistics conn reset slot
        if (disconnectLinkButton != null) {
            disconnectLinkButton.render(gfx, mouseX, mouseY, partialTick);
        }

    }

    // ── Fluid mode helpers ──────────────────────────────────────────────────────
    static int adjustFluidAmount(int cur, int dir, boolean shift, boolean ctrl, int min, int max) {
        int next = cur + dir * (ctrl ? 1 : shift ? 10 : 1000);
        if (!shift && !ctrl && cur % 1000 != 0) {           // 1-bucket step from an off-boundary value
            int boundary = dir > 0 ? (cur / 1000 + 1) * 1000 : (cur / 1000) * 1000;
            if (dir > 0 ? next > boundary : next < boundary) next = boundary;
        }
        return Mth.clamp(next, min, max);
    }

    static String formatFluidShort(int millibuckets) {
        if (millibuckets < 1000) return millibuckets + "mB";
        return new java.math.BigDecimal(millibuckets).movePointLeft(3)
            .setScale(1, java.math.RoundingMode.HALF_UP).stripTrailingZeros().toPlainString() + "B";
    }

    private void drawCenteredBoxLabel(GuiGraphics gfx, int x, int y, int width, String label) {
        gfx.drawString(font, label, x + (width - font.width(label)) / 2, y + 4, 0xFFEEEEEE, true);
    }

    private static final ResourceLocation SYMBOL_ADDRESS =
        ResourceLocation.fromNamespaceAndPath(CreateFactoryController.MODID, "symbols/address_tag");
    private static final ResourceLocation SYMBOL_GAUGE =
        ResourceLocation.fromNamespaceAndPath(CreateFactoryController.MODID, "symbols/factory_gauge");
    private static final int SYMBOL_ADVANCE = 9;

    private void drawPromiseLimitLabel(GuiGraphics gfx, int x, int y, int width, int active, int limit,
                                       boolean byAddress) {
        ResourceLocation symbol = byAddress ? SYMBOL_ADDRESS : SYMBOL_GAUGE;
        if (limit == 0) {
            String text = String.valueOf(active);
            int startX = x + (width - (SYMBOL_ADVANCE + font.width(text))) / 2;
            drawScopeSymbol(gfx, symbol, startX, y + 4, 0xFFEEEEEE);
            gfx.drawString(font, text, startX + SYMBOL_ADVANCE, y + 4, 0xFFEEEEEE, true);
            return;
        }
        int activeColor = active >= limit ? 0xFFFFBFA8 : 0xFFD7FFA8;   // red when at/over limit, else green
        String activeText = String.valueOf(active);
        String limitText = "/" + limit;
        int startX = x + (width - (SYMBOL_ADVANCE + font.width(activeText) + font.width(limitText))) / 2;
        drawScopeSymbol(gfx, symbol, startX, y + 4, activeColor);
        int tx = startX + SYMBOL_ADVANCE;
        gfx.drawString(font, activeText, tx, y + 4, activeColor, true);
        gfx.drawString(font, limitText, tx + font.width(activeText), y + 4, 0xFFEEEEEE, true);
    }

    private void drawScopeSymbol(GuiGraphics gfx, ResourceLocation symbol, int x, int y, int color) {
        int shadow = (color & 0xFF000000) | ((color >> 2) & 0x3F3F3F);
        RenderSystem.enableBlend();
        setColor(gfx, shadow);
        gfx.blitSprite(symbol, x + 1, y + 1, 8, 8);
        setColor(gfx, color);
        gfx.blitSprite(symbol, x, y, 8, 8);
        gfx.setColor(1f, 1f, 1f, 1f);
        RenderSystem.disableBlend();
    }

    private static void setColor(GuiGraphics gfx, int argb) {
        gfx.setColor(((argb >> 16) & 0xFF) / 255f, ((argb >> 8) & 0xFF) / 255f, (argb & 0xFF) / 255f,
            ((argb >>> 24) & 0xFF) / 255f);
    }

    private void renderThreshold(GuiGraphics gfx, @Nullable VirtualGaugeBehaviour behaviour) {
        // stock level
        if (behaviour != null && !behaviour.filter.isEmpty()) {
            int fx = panelX + FILTER_X, fy = panelY + THRESH_TOP;
            ResourceIconRenderer.render(gfx, behaviour.filter, fx, fy);
            gfx.pose().pushPose();
            gfx.pose().translate(0, 0, 200);
            SpriteNumbersRender.drawCount(gfx, FluidCompat.isFluidFilter(behaviour.filter)
                ? SpriteNumbersRender.abbreviateFluid(behaviour.stockLevel) :
                  SpriteNumbersRender.abbreviate(behaviour.stockLevel), fx, fy);
            gfx.pose().popPose();
        }
        // demand
        final boolean managed = behaviour != null && behaviour.isNumberManaged();
        String counttext;
        if (managed) {
            counttext = behaviour.numberManagedCountText();
        } else if (countEditing) {
            counttext = (countEdit.isEmpty() ? "" : countEdit) + ((System.currentTimeMillis() / 400) % 2 == 0 ? "_" : "");
        } else {
            counttext = thresholdCount == 0 && !requestMode.isPassive() ? "/" : String.valueOf(thresholdCount);
        }
        gfx.drawString(font, counttext, panelX + COUNT_X + 4, panelY + THRESH_TOP + 5,
                managed ? 0xFFD899FF : 0xFFFFFFFF, true);
        // unit
        gfx.drawString(font, mode.label().getString(), panelX + UNIT_X + 4, panelY + THRESH_TOP + 5,
                0xFFFFFFFF, true);

    }

    void drawItemCount(GuiGraphics gfx, ItemStack stack, int itemX, int itemY, String text) {
        if (ClientConfig.compactRecipeCountFont()) {
            gfx.pose().pushPose();
            gfx.pose().translate(0, 0, 200);
            // Right-align to the slot's right edge, matching the vanilla item-count placement it replaces.
            SpriteNumbersRender.drawCountRightAligned(gfx, text, itemX + 17, itemY + 10);
            gfx.pose().popPose();
        } else {
            gfx.renderItemDecorations(font, stack, itemX, itemY, text);
        }
    }

    @Override
    protected void renderForeground(GuiGraphics gfx, int mouseX, int mouseY, float partialTicks) {
        gfx.drawString(font, title, panelX + 97 - font.width(title) / 2, panelY + 4, 0x3D3C48, false);

        addressBox.render(gfx, mouseX, mouseY, partialTicks);
        gfx.flush();
        RenderSystem.clear(256, Minecraft.ON_OSX);

        super.renderForeground(gfx, mouseX, mouseY, partialTicks);
    }

    // ── Input ────────────────────────────────────────────────────────────────

    /** Create's GUI button blip (UI_BUTTON_CLICK, soft) — for value-box / slot clicks. */
    static void playClickSound() {
        Minecraft.getInstance().getSoundManager().play(
            SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK.value(), 1.0f, 0.25f));
    }

    /** Create's value-scroll blip (SCROLL_VALUE, pitch 1.5) — matches its ScrollInput widget. */
    static void playScrollSound() {
        Minecraft.getInstance().getSoundManager().play(
            SimpleSoundInstance.forUI(AllSoundEvents.SCROLL_VALUE.getMainEvent(), 1.5f));
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        // Deselect the address box when clicking away from it (mirrors FactoryPanelScreen).
        if (getFocused() != null && !getFocused().isMouseOver(mouseX, mouseY))
            setFocused(null);

        boolean onCountBox = countArea != null && countArea.isMouseOver(mouseX, mouseY);
        if (countEditing && !onCountBox) commitCountEdit();

        if (button == 1 && addressBox.isMouseOver(mouseX, mouseY)) {
            addressBox.setValue("");
            return true;
        }

        if (addressBox.mouseClicked(mouseX, mouseY, button)) {
            setFocused(addressBox);
            return true;
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    private int getEditCountValue(String editString) {
        try {
            int value = editString.isEmpty() ? 0 : Integer.parseInt(editString);
            return Mth.clamp(value, 0, mode.getMaxRequestCount());
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private void commitCountEdit() {
        if (!countEditing) return;
        thresholdCount = getEditCountValue(countEdit);
        countEditing = false;
        countEdit = "";
    }

    @Override
    public boolean charTyped(char codePoint, int modifiers) {
        if (countEditing) {
            if (codePoint >= '0' && codePoint <= '9')
                countEdit = String.valueOf(getEditCountValue(countEdit + codePoint));
            return true;
        }
        return super.charTyped(codePoint, modifiers);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (countEditing) {
            switch (keyCode) {
                case 257, 335, 256 -> commitCountEdit();   // Enter / numpad Enter / Escape → commit + leave edit
                case 259 -> {                              // Backspace
                    if (!countEdit.isEmpty()) countEdit = countEdit.substring(0, countEdit.length() - 1);
                }
                default -> { }
            }
            return true;   // capture all keys while typing so screen shortcuts (e.g. inventory) don't fire
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (button != 0 && ingredientArea != null && ingredientArea.mouseReleased(mouseX, mouseY, button)) return true;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (addressBox.mouseScrolled(mouseX, mouseY, scrollX, scrollY)) return true;
        return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
    }

    @Override
    public void onClose() {
        confirmAndReturn();
    }

    @Override
    public void removed() {
        Minecraft.getInstance().getSoundManager().play(
            SimpleSoundInstance.forUI(CreateFactoryController.GAUGE_UI_CLOSE.get(), 1f));
        super.removed();
    }

    @Override
    public List<net.minecraft.client.renderer.Rect2i> getExtraAreas() {
        return List.of(new net.minecraft.client.renderer.Rect2i(panelX + 195, panelY + 152, 52, 35));
    }

    // ── Commit ───────────────────────────────────────────────────────────────

    private void sendConfig(boolean clearPromises, boolean reset) {
        GaugeWorkModeEditor.Configuration config = editor().configuration();
        List<Boolean> exclusions = config.inputPositions().stream()
            .map(pos -> workMode != GaugeWorkMode.CRAFTING && multiplierExcludedInputs.contains(pos))
            .toList();
        PacketDistributor.sendToServer(new ConfigureRecipePacket(
            menu.controllerPos, gaugePos, addressBox.getValue(), outputCount, config.craftBatch(), maxRequestMultiplier,
            customRequestTimer, config.craftDimension(),
            promiseExpiration.getState(), promiseLimitState, promiseLimitByAddress, thresholdCount, mode, requestMode,
            workMode, config.inputPositions(), config.inputAmounts(), exclusions, config.craftingArrangement(),
            config.recipeSlots(), clearPromises, reset));
    }

    /** True if this gauge has any non-logistics connections */
    private boolean hasLinkConnections() {
        VirtualComponentBehaviour gauge = menu.componentAt(gaugePos);
        if (gauge == null) return false;
        return hasNonLogistics(gauge.incomingConnections()) || hasNonLogistics(gauge.outgoingConnections());
    }

    private static boolean hasNonLogistics(java.util.Collection<Connection> connections) {
        return connections.stream().anyMatch(c -> !LogisticsConnection.TYPE.equals(c.type));
    }

    private void setMode(ThresholdUnit newMode) {
        mode = newMode;
        thresholdCount = Mth.clamp(thresholdCount, 0, mode.getMaxRequestCount());
        if (fluidMode) {
            outputCount = Mth.clamp(outputCount, 1, VirtualGaugeBehaviour.FLUID_OUTPUT_CAP_MB);
        }
        playScrollSound();
    }

    private void cycleRequestMode() {
        requestMode = RequestMode.byOrdinal(requestMode.ordinal() + 1);
        if (requestModeButton != null) requestModeButton.setIcon(iconFor(requestMode));
        playClickSound();
    }

    private void confirmAndReturn() {
        sendConfig(false, false);
        Minecraft.getInstance().setScreen(controller);
    }

    private void deleteAndReturn() {
        sendConfig(false, true);
        Minecraft.getInstance().setScreen(controller);
    }
}
