package io.github.nbcss.createfactorycontroller.content.compat.jei;

import io.github.nbcss.createfactorycontroller.CreateFactoryController;
import io.github.nbcss.createfactorycontroller.content.component.gauge.GaugeFilterResolver;
import io.github.nbcss.createfactorycontroller.content.gui.screen.ConfigureRedstoneLinkScreen;
import io.github.nbcss.createfactorycontroller.content.gui.screen.controller.FactoryControllerScreen;
import io.github.nbcss.createfactorycontroller.content.gui.screen.NetworkSettingsScreen;
import io.github.nbcss.createfactorycontroller.content.gui.screen.SetItemScreen;
import mezz.jei.api.IModPlugin;
import mezz.jei.api.JeiPlugin;
import mezz.jei.api.gui.handlers.IGhostIngredientHandler;
import mezz.jei.api.gui.handlers.IGuiContainerHandler;
import mezz.jei.api.ingredients.ITypedIngredient;
import mezz.jei.api.recipe.IFocus;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.registration.IGuiHandlerRegistration;
import mezz.jei.api.runtime.IJeiRuntime;
import net.minecraft.client.renderer.Rect2i;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.NotNull;
import org.jspecify.annotations.NonNull;

import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * JEI integration. Only loaded when JEI is present (JEI scans for {@code @JeiPlugin}); references
 * only JEI API types (a {@code compileOnly} dependency), so a JEI-less client never classloads this.
 *
 * <p>Registers a ghost-ingredient handler on {@link SetItemScreen} so the player can drag an item
 * from JEI's list straight onto the gauge's ghost filter slot — no real item required.</p>
 *
 * <p>Also backs {@link JeiRecipes} with the runtime, so screens can open recipe pages.</p>
 */
@JeiPlugin
public class FactoryControllerJeiPlugin implements IModPlugin {

    private static final ResourceLocation UID =
            ResourceLocation.fromNamespaceAndPath(CreateFactoryController.MODID, "jei");

    @Override
    public ResourceLocation getPluginUid() {
        return UID;
    }

    @Override
    public void registerGuiHandlers(IGuiHandlerRegistration registration) {
        registration.addGhostIngredientHandler(SetItemScreen.class, new SetItemGhostHandler());
        // Keep the item list clear of the decorative gauge that protrudes from the panel.
        registration.addGuiContainerHandler(SetItemScreen.class, new IGuiContainerHandler<>() {
            @Override
            public @NonNull List<Rect2i> getGuiExtraAreas(@NonNull SetItemScreen screen) {
                return screen.extraGuiAreas();
            }
        });
        registration.addGhostIngredientHandler(ConfigureRedstoneLinkScreen.class, new RedstoneLinkGhostHandler());
        // Drag an item/fluid/gas from JEI straight onto an empty board gauge to set its filter (no set-item overlay).
        registration.addGhostIngredientHandler(FactoryControllerScreen.class, new FactoryControllerGhostHandler());
        registration.addGhostIngredientHandler(NetworkSettingsScreen.class, new NetworkSettingsGhostHandler());
    }

    @Override
    public void onRuntimeAvailable(IJeiRuntime runtime) {
        JeiRecipes.setHandler(new JeiRecipes.Handler() {
            @Override
            public boolean hasRecipes(Object ingredient) {
                return outputFocus(ingredient).map(focus -> runtime.getRecipeManager().createRecipeCategoryLookup()
                        .limitFocus(List.of(focus)).get().findAny().isPresent()).orElse(false);
            }

            @Override
            public void showRecipes(Object ingredient) {
                outputFocus(ingredient).ifPresent(focus -> runtime.getRecipesGui().show(focus));
            }

            private Optional<IFocus<?>> outputFocus(Object ingredient) {
                return runtime.getIngredientManager().createTypedIngredient(ingredient, true).<IFocus<?>>map(typed ->
                        runtime.getJeiHelpers().getFocusFactory().createFocus(RecipeIngredientRole.OUTPUT, typed));
            }
        });
    }

    @Override
    public void onRuntimeUnavailable() {
        JeiRecipes.setHandler(null);
    }

    /** Offers the network-settings icon slot as a JEI drop target (items only — the icon is a plain item). */
    private static class NetworkSettingsGhostHandler implements IGhostIngredientHandler<NetworkSettingsScreen> {
        @Override
        public <I> @NotNull List<Target<I>> getTargetsTyped(@NonNull NetworkSettingsScreen screen,
                                                            @NotNull ITypedIngredient<I> ingredient, boolean doStart) {
            List<Target<I>> targets = new ArrayList<>();
            Optional<ItemStack> stack = ingredient.getItemStack();
            if (stack.isPresent() && !stack.get().isEmpty()) {
                ItemStack icon = stack.get();
                targets.add(dropTarget(screen.ghostSlotArea(), () -> screen.setGhostFromJei(icon)));
            }
            return targets;
        }

        @Override
        public void onComplete() {}
    }

    /**
     * Offers every empty board gauge whose resolver converts the dragged ingredient into a filter it accepts.
     * JEI queries targets only when the hovered list ingredient changes and once at drag start, then keeps them for
     * the whole drag, so zooming the board mid-drag leaves the highlighted rects where they were.
     */
    private static class FactoryControllerGhostHandler implements IGhostIngredientHandler<FactoryControllerScreen> {

        @Override
        public <I> @NotNull List<Target<I>> getTargetsTyped(FactoryControllerScreen screen,
                                                            @NotNull ITypedIngredient<I> ingredient, boolean doStart) {
            List<Target<I>> targets = new ArrayList<>();
            Object dropped = ingredient.getIngredient();
            // Resolvers are shared per gauge type: convert once per resolver, not per gauge.
            Map<GaugeFilterResolver, ItemStack> keys = new IdentityHashMap<>();
            for (FactoryControllerScreen.GhostGaugeTarget t : screen.ghostGaugeTargets()) {
                ItemStack key = keys.computeIfAbsent(t.resolver(), r -> r.fromIngredient(dropped));
                if (!key.isEmpty()) targets.add(dropTarget(t.area(), () -> screen.setGaugeFilterFromJei(t.pos(), key)));
            }
            return targets;
        }

        @Override
        public void onComplete() {}
    }

    /** Offers the two frequency slots (Red/Blue) of the redstone-link config screen as JEI drop targets.
     *  Items only — redstone-link frequencies are plain items (no fluid-filter conversion). */
    private static class RedstoneLinkGhostHandler implements IGhostIngredientHandler<ConfigureRedstoneLinkScreen> {
        @Override
        public <I> List<Target<I>> getTargetsTyped(ConfigureRedstoneLinkScreen screen, ITypedIngredient<I> ingredient, boolean doStart) {
            List<Target<I>> targets = new ArrayList<>();
            Optional<ItemStack> stack = ingredient.getItemStack();
            if (stack.isPresent() && !stack.get().isEmpty()) {
                ItemStack freq = stack.get();
                targets.add(dropTarget(screen.redSlotArea(), () -> screen.setRedFromJei(freq)));
                targets.add(dropTarget(screen.blueSlotArea(), () -> screen.setBlueFromJei(freq)));
            }
            return targets;
        }

        @Override
        public void onComplete() {}
    }

    /** Offers the set-item screen's ghost slot when the gauge's resolver converts the dragged ingredient into a filter. */
    private static class SetItemGhostHandler implements IGhostIngredientHandler<SetItemScreen> {
        @Override
        public <I> @NotNull List<Target<I>> getTargetsTyped(SetItemScreen screen,
                                                            @NotNull ITypedIngredient<I> ingredient,
                                                            boolean doStart) {
            ItemStack key = screen.filterFromIngredient(ingredient.getIngredient());
            return key.isEmpty() ? List.of() : List.of(dropTarget(screen.ghostSlotArea(), () -> screen.setGhostFromJei(key)));
        }

        @Override
        public void onComplete() {}
    }

    /** A drop target over {@code area} that runs {@code action} on accept (ignoring the dropped value, which
     *  we've already captured as a concrete filter stack). */
    private static <I> IGhostIngredientHandler.Target<I> dropTarget(Rect2i area, Runnable action) {
        return new IGhostIngredientHandler.Target<>() {
            @Override
            public @NonNull Rect2i getArea() {
                return area;
            }

            @Override
            public void accept(@NonNull I dropped) {
                action.run();
            }
        };
    }
}
