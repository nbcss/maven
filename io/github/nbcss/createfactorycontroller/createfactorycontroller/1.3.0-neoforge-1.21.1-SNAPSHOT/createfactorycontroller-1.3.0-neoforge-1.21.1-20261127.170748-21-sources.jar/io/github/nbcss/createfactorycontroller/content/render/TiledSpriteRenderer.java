package io.github.nbcss.createfactorycontroller.content.render;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.GuiSpriteManager;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderStateShard;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.metadata.gui.GuiSpriteScaling;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.client.event.RegisterShadersEvent;
import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.concurrent.ExecutionException;

/**
 * Renders a sprite in a tiled or nine-sliced manner. Functionally similar to
 * {@link GuiGraphics#blitSprite(ResourceLocation, int, int, int, int, int) GuiGraphics#blitSprite}
 * where the sprite's scaling type is {@code tile} or {@code nine_slice}, but tiling is done in the shader instead of
 * with for loops issuing a draw call for every tile.
 */
@OnlyIn(Dist.CLIENT)
public abstract class TiledSpriteRenderer {

    // Define a custom vertex format and shader.
    // The fragment shader receives:
    // - uv in pixel coordinates within the sprite bounding box, starts at (0, 0) at top-left and will wrap outside the
    //   sprite size.
    // - Bounding box of the sprite in the texture atlas. The most suitable built-in VertexFormatElement are UV1 and
    //   UV2, making 4 i16's, as integers they are in pixel coordinates.

    private static final VertexFormat VERTEX_FORMAT = VertexFormat.builder()
            .add("Position", VertexFormatElement.POSITION)
            .add("Color", VertexFormatElement.COLOR)
            .add("UV0", VertexFormatElement.UV0)
            .add("SpriteMin", VertexFormatElement.UV1)
            .add("SpriteMax", VertexFormatElement.UV2)
            .build();

    private static final ResourceLocation SHADER_LOCATION = ResourceLocation.fromNamespaceAndPath("createfactorycontroller", "tiled_sprite");
    private static ShaderInstance shader;

    public static void registerShaders(RegisterShadersEvent event) {
        try {
            event.registerShader(new ShaderInstance(event.getResourceProvider(), SHADER_LOCATION, VERTEX_FORMAT), s -> shader = s);
        } catch (IOException exception) {
            throw new RuntimeException("could not reload shaders", exception);
        }
    }

    protected static ShaderInstance getShader() {
        return shader;
    }

    private static final RenderStateShard.ShaderStateShard SHADER_STATE =
            new RenderStateShard.ShaderStateShard(TiledSpriteRenderer::getShader);
    private static final Cache<ResourceLocation, RenderType> RENDER_TYPES =
            CacheBuilder.newBuilder().weakValues().build();

    private static RenderType createRenderType(ResourceLocation texture) {
        return RenderType.create("create_factory_controller_tiled_sprite",
                VERTEX_FORMAT, VertexFormat.Mode.QUADS, RenderType.TRANSIENT_BUFFER_SIZE,
                RenderType.CompositeState.builder()
                        .setShaderState(SHADER_STATE)
                        .setTextureState(new RenderStateShard.TextureStateShard(texture, false, false))
                        .setTransparencyState(RenderStateShard.TRANSLUCENT_TRANSPARENCY)
                        .setDepthTestState(RenderStateShard.LEQUAL_DEPTH_TEST)
                        .createCompositeState(false));
    }


    /**
     * Create a renderer for a sprite in "textures/gui/sprites" with an mcmeta file.
     */
    public static @NotNull TiledSpriteRenderer create(ResourceLocation spriteLocation) {
        GuiSpriteManager spriteManager = Minecraft.getInstance().getGuiSprites();
        var sprite = spriteManager.getSprite(spriteLocation);
        return create(sprite, spriteManager.getSpriteScaling(sprite));
    }

    /**
     * Create a renderer for any sprite in an atlas. provided with a scaling definition.
     */
    public static @NotNull TiledSpriteRenderer create(TextureAtlasSprite sprite, GuiSpriteScaling spriteScaling) {
        return create(sprite.atlasLocation(), sprite.getX(), sprite.getY(), spriteScaling);
    }

    /**
     * Create a renderer for any texture, provided with offsets and a scaling definition.
     * @param uOffset Staring u position of the sprite in pixels.
     * @param vOffset Staring v position of the sprite in pixels.
     */
    public static @NotNull TiledSpriteRenderer create(ResourceLocation atlasLocation, int uOffset, int vOffset, GuiSpriteScaling spriteScaling) {
        return switch (spriteScaling.type()) {
            case TILE -> new Tile(atlasLocation, uOffset, vOffset, (GuiSpriteScaling.Tile) spriteScaling);
            case NINE_SLICE -> new NineSlice(atlasLocation, uOffset, vOffset, (GuiSpriteScaling.NineSlice) spriteScaling);
            default -> throw new UnsupportedOperationException("Only sprites of type tile and nine_slice are supported");
        };
    }


    protected final ResourceLocation atlasLocation;
    protected final int uOffset, vOffset; // Offset of sprite in the atlas
    private final RenderType renderType;
    private int color = 0xFFFFFFFF;

    protected TiledSpriteRenderer(ResourceLocation atlasLocation, int uOffset, int vOffset) {
        this.atlasLocation = atlasLocation;
        this.uOffset = uOffset;
        this.vOffset = vOffset;

        try {
            renderType = RENDER_TYPES.get(atlasLocation, () -> createRenderType(atlasLocation));
        } catch (ExecutionException e) {
            throw new RuntimeException(e);
        }
    }

    public void render(@NotNull GuiGraphics graphics, int x, int y, int width, int height) {
        render(graphics, x, y, 0, width, height);
    }

    public void render(@NotNull GuiGraphics graphics, int x, int y, int blitOffset, int width, int height) {
        RenderSystem.setShaderTexture(0, atlasLocation);
        RenderSystem.setShader(TiledSpriteRenderer::getShader);
        BufferBuilder buffer = Tesselator.getInstance().begin(VertexFormat.Mode.QUADS, VERTEX_FORMAT);
        renderImpl(buffer, graphics.pose(), x, y, blitOffset, width, height);
        BufferUploader.drawWithShader(buffer.buildOrThrow());
    }

    public void render(MultiBufferSource bufferSource, PoseStack pose, int x, int y, int width, int height) {
        render(bufferSource, pose, x, y, 0, width, height);
    }

    public void render(MultiBufferSource bufferSource, PoseStack pose, int x, int y, int blitOffset, int width, int height) {
        renderImpl(bufferSource.getBuffer(renderType), pose, x, y, blitOffset, width, height);
    }

    public TiledSpriteRenderer setColorRGB(int color) {
        return setColorARGB(color | (0xFF << 24));
    }

    public TiledSpriteRenderer setColorARGB(int color) {
        this.color = color;
        return this;
    }

    protected abstract void renderImpl(VertexConsumer buffer, PoseStack pose, int x, int y, int blitOffset, int width, int height);

    public void endBatch(MultiBufferSource.BufferSource bufferSource) {
        bufferSource.endBatch(renderType);
    }


    // Helper
    protected void buildQuad(VertexConsumer buffer, PoseStack.Pose pose, int blitOffset,
                             int x1, int y1, int x2, int y2,
                             int u1, int v1, int u2, int v2) {
        int width = x2 - x1, height = y2 - y1;
        buffer.addVertex(pose, x1, y1, blitOffset)
                .setColor(color)
                .setUv(0, 0)
                .setUv1(u1, v1).setUv2(u2, v2);
        buffer.addVertex(pose, x1, y2, blitOffset)
                .setColor(color)
                .setUv(0, height)
                .setUv1(u1, v1).setUv2(u2, v2);
        buffer.addVertex(pose, x2, y2, blitOffset)
                .setColor(color)
                .setUv(width, height)
                .setUv1(u1, v1).setUv2(u2, v2);
        buffer.addVertex(pose, x2, y1, blitOffset)
                .setColor(color)
                .setUv(width, 0)
                .setUv1(u1, v1).setUv2(u2, v2);
    }


    /**
     * Renders the sprite tiled.
     */
    public static class Tile extends TiledSpriteRenderer {

        protected final GuiSpriteScaling.Tile spriteScaling;

        protected Tile(ResourceLocation atlasLocation, int uOffset, int vOffset, GuiSpriteScaling.Tile spriteScaling) {
            super(atlasLocation, uOffset, vOffset);
            this.spriteScaling = spriteScaling;
        }

        @Override
        protected void renderImpl(VertexConsumer buffer, PoseStack pose, int x, int y, int blitOffset, int width, int height) {
            buildQuad(buffer, pose.last(), blitOffset,
                    x, y, x + width, y + height,
                    uOffset, vOffset, uOffset + spriteScaling.width(), vOffset + spriteScaling.height());
        }
    }

    /**
     * Renders the sprite in a nine-sliced manner.
     */
    public static class NineSlice extends TiledSpriteRenderer {

        protected final GuiSpriteScaling.NineSlice spriteScaling;

        protected NineSlice(ResourceLocation atlasLocation, int uOffset, int vOffset, GuiSpriteScaling.NineSlice spriteScaling) {
            super(atlasLocation, uOffset, vOffset);
            this.spriteScaling = spriteScaling;
        }

        @Override
        protected void renderImpl(VertexConsumer buffer, PoseStack pose, int x, int y, int blitOffset, int width, int height) {
            var border = spriteScaling.border();

            //            x,u
            //       0   1   2   3
            //    0  -------------
            //       | 0 | 1 | 2 |
            // y  1  |---|---|---|
            // ,     | 3 | 4 | 5 |
            // v  2  |---|---|---|
            //       | 6 | 7 | 8 |
            //    3  -------------

            // Slice the sprite with 4x4 vertices.
            int[] xs = {x, x + border.left(), x + width - border.right(), x + width};
            int[] ys = {y, y + border.top(), y + height - border.bottom(), y + height};
            int[] us = {
                    uOffset, uOffset + border.left(),
                    uOffset + spriteScaling.width() - border.right(), uOffset + spriteScaling.width()
            };
            int[] vs = {
                    vOffset, vOffset + border.top(),
                    vOffset + spriteScaling.height() - border.bottom(), vOffset + spriteScaling.height()
            };

            // Build the 9 quads.
             for (int i = 0; i < 9; i++) {
                 buildQuad(buffer, pose.last(), blitOffset,
                         xs[i % 3], ys[i / 3], xs[i % 3 + 1], ys[i / 3 + 1],
                         us[i % 3], vs[i / 3], us[i % 3 + 1], vs[i / 3 + 1]);
             }
        }
    }
}
